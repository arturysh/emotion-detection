/** @type {import('jest').Config} */
module.exports = {
    clearMocks: true,
    collectCoverage: true,
    coverageDirectory: "coverage",
    coverageProvider: "v8",
    moduleNameMapper: {
        "^.+\\.css$": "<rootDir>/test/styleMock.ts",
        "^.+\\.(png|jpg|jpeg|gif|svg)$": "<rootDir>/test/fileMock.ts",
        "^@/(.*)$": "<rootDir>/src/$1"
    },
    setupFilesAfterEnv: ["<rootDir>/test/setupTests.ts"],
    testEnvironment: "jsdom",
    verbose: true,
    transform: {
        "^.+\\.(ts|tsx)$": "ts-jest",
    },
    moduleFileExtensions: ["ts", "tsx", "js", "jsx", "json", "node"],
    testMatch: ["**/__tests__/**/*.[jt]s?(x)", "**/?(*.)+(spec|test).[jt]s?(x)"],
    transformIgnorePatterns: [
        "/node_modules/(?!(@testing-library|@emotion)/)"
    ],
}; 