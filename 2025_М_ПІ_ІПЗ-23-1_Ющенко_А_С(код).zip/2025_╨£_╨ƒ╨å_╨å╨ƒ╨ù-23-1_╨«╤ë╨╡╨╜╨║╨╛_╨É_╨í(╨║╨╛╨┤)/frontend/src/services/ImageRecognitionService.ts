class EmotionAnalysisService {
    private baseUrl: string;

    constructor() {
        this.baseUrl = 'http://localhost:5000';
    }

    async analyzeFile(file: File): Promise<any> {
        try {
            const formData = new FormData();
            formData.append('file', file);

            const response = await fetch(
                `${this.baseUrl}/api/analyze`,
                {
                    method: 'POST',
                    body: formData,
                }
            );

            if (!response.ok) {
                const errorData = await response.json().catch(() => null);
                throw new Error(errorData?.error || `Ошибка сервера: ${response.status}`);
            }

            const data = await response.json();
            return data;
        } catch (error) {
            if (error instanceof Error) {
                if (error.message.includes('Unexpected token') || error.message.includes('is not valid JSON')) {
                    throw new Error('Ошибка обработки данных на сервере. Пожалуйста, попробуйте другой файл.');
                }
                throw new Error(`Ошибка анализа: ${error.message}`);
            }
            throw new Error('Неизвестная ошибка при анализе файла');
        }
    }

    async analyzeUrl(url: string): Promise<any> {
        try {
            const response = await fetch(
                `${this.baseUrl}/api/analyze-url`,
                {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ url }),
                }
            );

            if (!response.ok) {
                const errorData = await response.json().catch(() => null);
                throw new Error(errorData?.error || `Ошибка сервера: ${response.status}`);
            }

            const data = await response.json();
            return data;
        } catch (error) {
            if (error instanceof Error) {
                if (error.message.includes('Unexpected token') || error.message.includes('is not valid JSON')) {
                    throw new Error('Ошибка обработки данных на сервере. Пожалуйста, попробуйте другой URL.');
                }
                throw new Error(`Ошибка анализа: ${error.message}`);
            }
            throw new Error('Неизвестная ошибка при анализе URL');
        }
    }
}

export const emotionService = new EmotionAnalysisService();