import Header from "../../common/Header/Header";
import {ReactElement} from "react";
import FileUpload from "../../common/UploadFile/FileUpload";

function MainPage(): ReactElement {
    return (
        <div>
            <Header/>
            <FileUpload />
        </div>
    )
}

export default MainPage;