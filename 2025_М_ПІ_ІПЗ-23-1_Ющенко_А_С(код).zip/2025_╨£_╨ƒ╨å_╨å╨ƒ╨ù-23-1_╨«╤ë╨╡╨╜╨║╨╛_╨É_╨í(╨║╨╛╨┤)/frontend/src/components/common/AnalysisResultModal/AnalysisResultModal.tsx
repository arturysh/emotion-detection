import React, { useState } from 'react';

type Probabilities = { [emotion: string]: number };

interface Metrics {
    certainty_score: number;
    input_shape: string;
    prediction_entropy: number;
    prediction_margin: number;
    processing_time_ms: number;
}

interface ModelResult {
    confidence: number;
    emotion: string;
    metrics: Metrics;
    probabilities: Probabilities;
}

interface PerformanceSummary {
    average_processing_time_ms: number;
    fastest_model: string;
    models_failed: number;
    models_processed: number;
    preprocessing_time_ms: number;
    total_processing_time_ms: number;
}

interface ProbabilityBarProps {
    emotion: string;
    probability: number;
    isTop: boolean;
    color: string;
}

interface FrameAnalysis {
    image_base64: string;
    predictions: Record<string, ModelResult>;
}

interface BaseAnalysisData {
    _performance_summary: PerformanceSummary;
    media_type: 'video' | 'image';
    filename?: string;
}

interface VideoAnalysisData extends BaseAnalysisData {
    media_type: 'video';
    frames: FrameAnalysis[];
    summary: Record<string, ModelResult>;
    filename: string;
}

interface ImageAnalysisData extends BaseAnalysisData {
    media_type: 'image';
    image_base64?: string;
    preview_image_base64?: string;
    filename?: string;
    [key: string]: ModelResult | PerformanceSummary | string | undefined;
}

type AnalysisModalData = VideoAnalysisData | ImageAnalysisData;

interface AnalysisResultModalProps {
    isOpen: boolean;
    onClose: () => void;
    data: AnalysisModalData | null;
}


const ProbabilityBar: React.FC<ProbabilityBarProps> = ({ emotion, probability, isTop, color }) => {
    const percentage = (probability * 100).toFixed(1);
    return (
        <div className="w-full flex items-center text-xs mb-1 group">
            <span className="w-24 capitalize text-gray-600 truncate">{emotion}</span>
            <div className="flex-grow bg-gray-200 rounded-full h-4 mr-2 overflow-hidden">
                <div
                    className={`h-4 rounded-full transition-all duration-300 ${color}`}
                    style={{ width: `${percentage}%` }}
                />
            </div>
            <span className={`w-10 text-right font-medium ${isTop ? 'text-gray-800' : 'text-gray-500'}`}>{percentage}%</span>
        </div>
    );
};

function isModelResult(value: any): value is ModelResult {
    return value && typeof value === 'object' && 'confidence' in value && 'probabilities' in value;
}


const AnalysisResultModal: React.FC<AnalysisResultModalProps> = ({ isOpen, onClose, data }) => {
    const [frameIdx, setFrameIdx] = useState(0);

    if (!isOpen || !data) {
        return null;
    }

    const isVideo = data.media_type === 'video';
    const frames = isVideo ? (data as VideoAnalysisData).frames : null;

    const _performance_summary = data._performance_summary;
    console.log(data);

    const sortedModels = Object.entries(data)
        .filter(([, value]) => isModelResult(value))
        .sort(([, a], [, b]) => (b as ModelResult).confidence - (a as ModelResult).confidence) as [string, ModelResult][];
    console.log(sortedModels);

    const emotionColors: Record<string, string> = {
        happy: 'text-green-500',
        sad: 'text-blue-500',
        angry: 'text-red-500',
        fear: 'text-purple-500',
        surprise: 'text-yellow-500',
        neutral: 'text-gray-500',
        disgust: 'text-teal-500',
    };

    const emotionEmojis: Record<string, string> = {
        happy: '😊',
        sad: '😢',
        angry: '😠',
        fear: '😨',
        surprise: '😲',
        neutral: '😐',
        disgust: '🤮',
    };

    let currentFrame = null;
    let currentPredictions = null;
    if (isVideo && frames && frames.length > 0) {
        currentFrame = frames[frameIdx];
        currentPredictions = currentFrame.predictions;
    }

    return (
        <div className="fixed inset-0 bg-transparent bg-opacity-60 flex justify-center items-center z-50 p-4" onClick={onClose}>
            <div
                className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col"
                onClick={(e: React.MouseEvent) => e.stopPropagation()}
            >
                <div className="p-6 border-b border-gray-200 flex justify-between items-center flex-shrink-0">
                    <h2 className="text-2xl font-bold text-gray-800">Emotion Analysis Results</h2>
                    <button onClick={onClose} className="!bg-blue !text-white hover:text-gray-600 text-2xl">&times;</button>
                </div>

                <div className="p-6 overflow-y-auto">
                    {isVideo && frames && frames.length > 0 ? (
                        <div className="flex flex-col items-center mb-6">
                            <div className="mb-2 text-gray-700 text-sm font-medium truncate max-w-full">
                                File: {data.filename}
                            </div>
                            <div className="relative w-full max-w-2xl mb-4">
                                <img
                                    src={`data:image/jpeg;base64,${frames[frameIdx].image_base64}`}
                                    className="w-full rounded-lg shadow-lg max-h-[400px] !w-auto mx-auto"
                                    alt={`Frame ${frameIdx + 1}`}
                                />
                                <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 bg-black bg-opacity-50 text-white px-3 py-1 rounded-full text-sm">
                                    Frame {frameIdx + 1} of {frames.length}
                                </div>
                            </div>
                            
                            <div className="flex items-center gap-4 mb-6">
                                <button
                                    className="px-4 py-2 rounded-lg bg-blue-500 text-white hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                                    onClick={() => setFrameIdx(idx => Math.max(0, idx - 1))}
                                    disabled={frameIdx === 0}
                                >
                                    ← Previous
                                </button>
                                <button
                                    className="px-4 py-2 rounded-lg bg-blue-500 text-white hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                                    onClick={() => setFrameIdx(idx => Math.min(frames.length - 1, idx + 1))}
                                    disabled={frameIdx === frames.length - 1}
                                >
                                    Next →
                                </button>
                            </div>

                            <div className="w-full max-w-2xl">
                                <h3 className="text-lg font-semibold mb-4">Current Frame Analysis</h3>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    {Object.entries(frames[frameIdx].predictions)
                                        .filter(([, value]) => isModelResult(value))
                                        .map(([modelName, modelData]) => (
                                            <div key={modelName} className="border border-gray-200 rounded-lg p-4">
                                                <h4 className="font-bold text-gray-800 mb-2">{modelName}</h4>
                                                <div className="text-center">
                                                    <div className={`text-2xl font-bold ${emotionColors[(modelData as ModelResult).emotion]} capitalize mb-2 flex items-center justify-center gap-2`}>
                                                        <span className="text-3xl">{emotionEmojis[(modelData as ModelResult).emotion]}</span>
                                                        {(modelData as ModelResult).emotion}
                                                    </div>
                                                    <div className="text-sm text-gray-600">
                                                        Confidence: {(modelData as ModelResult).confidence * 100}%
                                                    </div>
                                                </div>
                                            </div>
                                        ))}
                                </div>
                            </div>
                        </div>
                    ) : (
                        (data as ImageAnalysisData).filename && (
                            <div className="flex flex-col items-center mb-6">
                                <div className="mb-2 text-gray-700 text-sm font-medium truncate max-w-full">
                                    File: {(data as ImageAnalysisData).filename}
                                </div>
                                {((data as ImageAnalysisData).image_base64 || (data as ImageAnalysisData).preview_image_base64) && (
                                    <img
                                        src={`data:image/jpeg;base64,${(data as ImageAnalysisData).image_base64 || (data as ImageAnalysisData).preview_image_base64}`}
                                        className="max-h-64 rounded shadow mb-2 border"
                                        style={{objectFit: 'contain'}}
                                        alt="Analyzed image"
                                    />
                                )}

                                <div className="w-full max-w-2xl mt-6">
                                    <h3 className="text-lg font-semibold mb-4">Analysis Results</h3>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        {sortedModels.map(([modelName, modelData]) => (
                                            <div key={modelName} className="border border-gray-200 rounded-lg p-4">
                                                <h4 className="font-bold text-gray-800 mb-2">{modelName}</h4>
                                                <div className="text-center">
                                                    <div className={`text-2xl font-bold ${emotionColors[modelData.emotion]} capitalize mb-2 flex items-center justify-center gap-2`}>
                                                        <span className="text-3xl">{emotionEmojis[modelData.emotion]}</span>
                                                        {modelData.emotion}
                                                    </div>
                                                    <div className="text-sm text-gray-600">
                                                        Confidence: {(modelData.confidence * 100).toFixed(1)}%
                                                    </div>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                        </div>
                        )
                    )}
                </div>
            </div>
        </div>
    );
};

export default AnalysisResultModal;