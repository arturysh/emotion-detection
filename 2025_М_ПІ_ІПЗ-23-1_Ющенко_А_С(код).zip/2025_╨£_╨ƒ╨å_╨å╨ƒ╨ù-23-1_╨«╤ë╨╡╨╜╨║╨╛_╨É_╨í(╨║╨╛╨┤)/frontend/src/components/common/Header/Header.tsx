import {ReactElement} from "react";
import logoImg from "@/assets/images/logo.png";

function Header(): ReactElement {
    return (
        <header className={"pt-[30px] flex h-[80px] w-full items-center justify-center mb-[-80px]"}>
            <div className={"mx-2 h-full"}>
                <img src={logoImg} alt={"logo emotions.ai"} className={"h-full w-auto"}/>
            </div>
        </header>
    )
}

export default Header;