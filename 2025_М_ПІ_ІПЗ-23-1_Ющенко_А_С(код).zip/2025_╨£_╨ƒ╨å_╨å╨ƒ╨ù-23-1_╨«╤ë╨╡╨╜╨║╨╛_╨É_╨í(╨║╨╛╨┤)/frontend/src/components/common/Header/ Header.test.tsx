import '@testing-library/jest-dom';
import { render, screen } from '@testing-library/react';
import Header from './Header';

describe('Header component', () => {
    it('renders the logo image with correct alt text', () => {
        render(<Header />);

        const logo = screen.getByAltText(/logo emotions\.ai/i);
        expect(logo).toBeInTheDocument();
        expect(logo.tagName).toBe('IMG');
    });

    it('has an image with a src attribute', () => {
        render(<Header />);

        const logo = screen.getByAltText(/logo emotions\.ai/i) as HTMLImageElement;
        expect(logo).toHaveAttribute('src');
    });
});