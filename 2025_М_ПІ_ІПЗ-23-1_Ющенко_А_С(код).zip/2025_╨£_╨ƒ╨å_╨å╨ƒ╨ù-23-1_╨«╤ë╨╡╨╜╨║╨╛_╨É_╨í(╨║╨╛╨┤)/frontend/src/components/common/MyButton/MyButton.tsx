import React from 'react'

function MyButton({children, ...props}) {
    return (
        <button {...props} className={`${props.className} ${props.disabled ? 'disabled disabled:!bg-[#b2b2b2] dark:disabled:!bg-[#4B4B4B]' : ""} text-dark-text-light-color bg-light-accent hover:bg-light-accent-hover dark:bg-dark-accent dark:hover:bg-dark-accent-hover`}>
            {children}
        </button>
    )
}

export default MyButton