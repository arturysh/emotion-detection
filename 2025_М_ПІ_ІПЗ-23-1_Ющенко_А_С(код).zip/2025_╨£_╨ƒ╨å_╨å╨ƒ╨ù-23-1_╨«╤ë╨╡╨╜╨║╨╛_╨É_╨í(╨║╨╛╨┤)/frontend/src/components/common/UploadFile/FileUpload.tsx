import {useState, useRef} from 'react';
import {emotionService} from "../../../services/ImageRecognitionService";
import AnalysisResultModal from "../AnalysisResultModal/AnalysisResultModal";

export default function FileUpload() {
    const [selectedFile, setSelectedFile] = useState(null);
    const [isDragOver, setIsDragOver] = useState(false);
    const [isAnalyzing, setIsAnalyzing] = useState(false);
    const [uploadProgress, setUploadProgress] = useState(0);
    const [isAnalyzed, setIsAnalyzed] = useState(false);
    const [analysisResult, setAnalysisResult] = useState(null);
    const [error, setError] = useState('');
    const [urlInput, setUrlInput] = useState('');
    const [activeTab, setActiveTab] = useState('file');
    const [showHistory, setShowHistory] = useState(false);
    const fileInputRef = useRef(null);
    const [isModalOpen, setIsModalOpen] = useState(false);


    const [analysisHistory, setAnalysisHistory] = useState([
        {
            id: 1,
            date: 'Jun 16, 2025 - 22:30',
            type: 'image',
            name: 'IMG_7324.jpg',
            result: 'Happy (57.3%)',
            source: 'file'
        },
        {
            id: 2,
            date: 'Jun 16, 2025 - 21:19',
            type: 'video',
            name: 'IMG_3241.mp4',
            result: 'Confident (42.1%)',
            source: 'file'
        },
        {
            id: 3,
            date: 'Jun 16, 2025 - 21:11',
            type: 'image',
            name: 'https://media.istockphoto.com/id/873338814/photo/beautiful-young-woman-with-pale-white-skin-rose-color-blush-cheeks-and-pink-lipstick.jpg?s=612x612&w=0&k=20&c=SGCm3d74JcvU4ylRaHgk15-EMpnJcinOhZHgUtF4yk4=',
            result: 'Surprised (58.9%)',
            source: 'url'
        },
        {
            id: 4,
            date: 'Jun 16, 2025 - 21:03',
            type: 'video',
            name: 'IMG_3041.mp4',
            result: 'Neutral (44.5%)',
            source: 'file'
        },
    ]);

    const isValidFile = (file) => {
        const maxSize = 50 * 1024 * 1024;
        const validImageTypes = ['image/jpeg', 'image/jpg', 'image/png'];
        const validVideoTypes = ['video/mp4', 'video/avi', 'video/mov'];
        const validTypes = [...validImageTypes, ...validVideoTypes];

        if (file.size > maxSize) {
            return {valid: false, error: 'File size must be less than 50 MB'};
        }

        if (!validTypes.includes(file.type)) {
            return {
                valid: false,
                error: 'Supported formats: JPG, JPEG, PNG (images) and MP4, AVI, MOV (videos)'
            };
        }

        return {valid: true};
    };

    const isValidUrl = (url) => {
        try {
            const urlObj = new URL(url);
            const validDomains = ['youtube.com', 'youtu.be', 'vimeo.com', 'imgur.com', 'flickr.com'];
            const hasValidExtension = /\.(jpg|jpeg|png|gif|mp4|avi|mov|webm)$/i.test(urlObj.pathname);
            const hasValidDomain = validDomains.some(domain => urlObj.hostname.includes(domain));

            if (!hasValidExtension && !hasValidDomain) {
                return {
                    valid: false,
                    error: 'URL must be a direct link to an image/video or from supported platforms (YouTube, Vimeo, etc.)'
                };
            }

            return {valid: true};
        } catch {
            return {valid: false, error: 'Please enter a valid URL'};
        }
    };

    const handleFileSelect = async (file) => {
        if (!file) return;

        const validation = isValidFile(file);
        if (!validation.valid) {
            setError(validation.error || 'Invalid file');
            return;
        }

        setSelectedFile(file);
        setIsAnalyzing(true);
        setUploadProgress(0);
        setIsAnalyzed(false);
        setAnalysisResult(null);
        setError('');
        setAnalysisResult(null);

        try {
            const progressInterval = setInterval(() => {
                setUploadProgress((prev) => Math.min(prev + 10, 90));
            }, 200);

            const result = await emotionService.analyzeFile(file);

            clearInterval(progressInterval);
            setUploadProgress(100);
            setIsAnalyzing(false);
            setIsAnalyzed(true);
            setAnalysisResult(result);
            setIsModalOpen(true);
            const date = new Date();

            const optionsDate = { year: 'numeric', month: 'short', day: 'numeric' };
            const optionsTime = { hour: '2-digit', minute: '2-digit', hour12: false };

            const formattedDate = date.toLocaleDateString('en-US', optionsDate);
            const formattedTime = date.toLocaleTimeString('en-US', optionsTime);

            const timeResult = `${formattedDate} - ${formattedTime}`;
            setAnalysisHistory(prevHistory => [{
                id: prevHistory.length + 1,
                date: timeResult,
                type: result?.media_type,
                name: result?.filename,
                result: `${result?.cnn_fer2013_net?.emotion} (${(result?.cnn_fer2013_net?.confidence ?? 0).toFixed(2)}%)`,
                source: result?.source_type,
                result_a: result,
            }, ...prevHistory]);
        } catch (error) {
            setIsAnalyzing(false);
            setUploadProgress(0);
            const errorMessage = error instanceof Error ? error.message : 'Analysis failed';
            setError(errorMessage);
            setAnalysisResult('');
        }
    };

    const handleUrlSubmit = async () => {
        if (!urlInput.trim()) {
            setError('Please enter a URL');
            return;
        }

        const validation = isValidUrl(urlInput);
        if (!validation.valid) {
            setError(validation.error || 'Invalid URL');
            return;
        }

        setIsAnalyzing(true);
        setUploadProgress(0);
        setIsAnalyzed(false);
        setAnalysisResult('');
        setError('');
        setAnalysisResult(null);
        try {
            const progressInterval = setInterval(() => {
                setUploadProgress((prev) => Math.min(prev + 10, 90));
            }, 200);

            const result = await emotionService.analyzeUrl(urlInput);

            clearInterval(progressInterval);
            setUploadProgress(100);
            setIsAnalyzing(false);
            setIsAnalyzed(true);
            setAnalysisResult(result);
            setIsModalOpen(true);
            const date = new Date();

            const optionsDate = { year: 'numeric', month: 'short', day: 'numeric' };
            const optionsTime = { hour: '2-digit', minute: '2-digit', hour12: false };

            const formattedDate = date.toLocaleDateString('en-US', optionsDate);
            const formattedTime = date.toLocaleTimeString('en-US', optionsTime);

            const timeResult = `${formattedDate} - ${formattedTime}`;
            setAnalysisHistory(prevHistory => [{
                id: prevHistory.length + 1,
                date: timeResult,
                type: result?.media_type,
                name: result?.filename,
                result: `${result?.cnn_fer2013_net?.emotion} (${(result?.cnn_fer2013_net?.confidence ?? 0).toFixed(2)}%)`,
                source: result?.source_type,
                result_a: result,
            }, ...prevHistory]);
        } catch (error) {
            setIsAnalyzing(false);
            setUploadProgress(0);
            const errorMessage = error instanceof Error ? error.message : 'Analysis failed';
            setError(errorMessage);
            setAnalysisResult('');
        }
    };

    const handleFileChange = (e) => {
        const file = e.target.files?.[0];
        if (file) {
            handleFileSelect(file);
        }
    };

    const handleDragOver = (e) => {
        e.preventDefault();
        setIsDragOver(true);
    };

    const handleDragLeave = () => {
        setIsDragOver(false);
    };

    const handleDrop = (e) => {
        e.preventDefault();
        setIsDragOver(false);
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            const file = files[0];
            handleFileSelect(file);
        }
    };

    const handleLabelClick = () => {
        fileInputRef.current?.click();
    };

    const resetUpload = () => {
        setSelectedFile(null);
        setIsAnalyzing(false);
        setUploadProgress(0);
        setIsAnalyzed(false);
        setAnalysisResult('');
        setError('');
        setUrlInput('');
        if (fileInputRef.current) {
            fileInputRef.current.value = '';
        }
    };

    const getFileTypeIcon = (file) => {
        if (file.type.startsWith('image/')) return '🖼️';
        if (file.type.startsWith('video/')) return '🎥';
        return '📁';
    };

    const getHistoryIcon = (type, source) => {
        if (type === 'image') return source === 'url' ? '🔗🖼️' : '🖼️';
        if (type === 'video') return source === 'url' ? '🔗🎥' : '🎥';
        return '📁';
    };

    return (
        <>
            <div
                className="min-h-screen bg-gradient-to-br from-purple-100 to-blue-100 flex items-center justify-center font-sans p-4">
                <div className="flex gap-6 w-full max-w-6xl justify-center">
                    <div className="!bg-white rounded-2xl shadow-xl p-8 w-full max-w-md">
                        <h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">
                            Emotion Analysis
                        </h2>
                        <div className="!flex !mb-6 !bg-gray-100 !rounded-lg !p-1">
                            <button
                                onClick={() => setActiveTab('file')}
                                className={`!flex-1 !py-2 !px-4 !rounded-md !text-sm !font-medium !transition-all !duration-200 ${
                                    activeTab === 'file'
                                        ? '!bg-white !text-gray-900 !shadow-sm'
                                        : '!bg-transparent !text-gray-600 !hover:text-gray-900'
                                }`}
                            >
                                📁 Upload File
                            </button>
                            <button
                                onClick={() => setActiveTab('url')}
                                className={`!flex-1 !py-2 !px-4 !rounded-md !text-sm !font-medium !transition-all !duration-200 ${
                                    activeTab === 'url'
                                        ? '!bg-white !text-gray-900 !shadow-sm'
                                        : '!bg-transparent !text-gray-600 !hover:text-gray-900'
                                }`}
                            >
                                🔗 From URL
                            </button>
                        </div>

                        <div className="relative w-full mb-6">
                            {activeTab === 'file' ? (
                                <div
                                    className={`relative ${isDragOver ? 'scale-105' : ''} transition-transform duration-300`}
                                    onDragOver={handleDragOver}
                                    onDragLeave={handleDragLeave}
                                    onDrop={handleDrop}
                                >
                                    <input
                                        ref={fileInputRef}
                                        type="file"
                                        id="fileInput"
                                        name="file"
                                        accept="image/jpeg,image/jpg,image/png,video/mp4,video/avi,video/mov"
                                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                                        onChange={handleFileChange}
                                        disabled={isAnalyzing}
                                    />

                                    <label
                                        htmlFor="fileInput"
                                        className={`
                                        flex flex-col items-center justify-center w-full p-8 min-h-[120px]
                                        ${isDragOver
                                            ? 'bg-blue-50 border-blue-400'
                                            : 'bg-gray-50 border-gray-300'
                                        }
                                        ${isAnalyzing ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer hover:bg-gray-100'}
                                        border-2 border-dashed rounded-xl text-center transition-all duration-300
                                    `}
                                        onClick={handleLabelClick}
                                    >
                                        <span className="text-4xl mb-3">📁</span>
                                        <span className="text-sm text-gray-600 font-medium">
                                        {isAnalyzing ? 'Analyzing...' : 'Upload or drag and drop files'}
                                    </span>
                                        <span className="text-xs text-gray-400 mt-1">
                                        Images: JPG, PNG • Videos: MP4, AVI, MOV • Max: 50MB
                                    </span>
                                    </label>
                                </div>
                            ) : (
                                <div className="space-y-4">
                                    <div>
                                        <label htmlFor="urlInput"
                                               className="block text-sm font-medium text-gray-700 mb-2">
                                            Enter image or video URL
                                        </label>
                                        <input
                                            id="urlInput"
                                            type="url"
                                            value={urlInput}
                                            onChange={(e) => setUrlInput(e.target.value)}
                                            placeholder="https://example.com/image.jpg"
                                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                            disabled={isAnalyzing}
                                        />
                                        <p className="text-xs text-gray-500 mt-1">
                                            Supports direct links to images/videos or URLs from YouTube, Vimeo, etc.
                                        </p>
                                    </div>
                                    <button
                                        onClick={handleUrlSubmit}
                                        disabled={isAnalyzing || !urlInput.trim()}
                                        className={`w-full py-2 px-4 rounded-md font-medium transition-all duration-200 ${
                                            isAnalyzing || !urlInput.trim()
                                                ? '!bg-gray-300 !text-gray-500 !cursor-not-allowed'
                                                : '!bg-blue-500 !text-white !hover:bg-blue-600 !active:bg-blue-700'
                                        }`}
                                    >
                                        {isAnalyzing ? 'Analyzing...' : 'Analyze URL'}
                                    </button>
                                </div>
                            )}

                            {(isAnalyzing || isAnalyzed) && (
                                <div className="w-full h-3 bg-gray-200 mt-4 rounded-full overflow-hidden">
                                    <div
                                        className={`h-full rounded-full transition-all duration-300 ${
                                            isAnalyzed ? 'bg-green-500' : 'bg-blue-500'
                                        }`}
                                        style={{width: `${uploadProgress}%`}}
                                    />
                                </div>
                            )}

                            {selectedFile && activeTab === 'file' && (
                                <div className="!mt-4 !p-3 !bg-gray-50 !rounded-lg">
                                    <div className="!flex !items-center !justify-between">
                                        <div className="!flex !items-center !space-x-2">
                                            <span className="text-lg">{getFileTypeIcon(selectedFile)}</span>
                                            <div>
                                                <div
                                                    className="!text-sm !font-medium !text-gray-800 !truncate m!ax-w-[200px]">
                                                    {selectedFile.name}
                                                </div>
                                                <div className="!text-xs !text-gray-500">
                                                    {(selectedFile.size / (1024 * 1024)).toFixed(2)} MB
                                                </div>
                                            </div>
                                        </div>
                                        {!isAnalyzing && (
                                            <button
                                                onClick={resetUpload}
                                                className="!text-gray-400 !hover:text-gray-600 !text-sm"
                                            >
                                                ✕
                                            </button>
                                        )}
                                    </div>
                                </div>
                            )}

                            {urlInput && activeTab === 'url' && (isAnalyzing || isAnalyzed) && (
                                <div className="mt-4 p-3 bg-gray-50 rounded-lg">
                                    <div className="flex items-center justify-between">
                                        <div className="flex items-center space-x-2">
                                            <span className="text-lg">🔗</span>
                                            <div>
                                                <div
                                                    className="text-sm font-medium text-gray-800 truncate max-w-[200px]">
                                                    {urlInput}
                                                </div>
                                                <div className="text-xs text-gray-500">
                                                    External URL
                                                </div>
                                            </div>
                                        </div>
                                        {!isAnalyzing && (
                                            <button
                                                onClick={resetUpload}
                                                className="!text-gray-400 !hover:text-gray-600 !text-sm"
                                            >
                                                ✕
                                            </button>
                                        )}
                                    </div>
                                </div>
                            )}

                            {analysisResult && (
                                <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg">
                                    <div className="flex items-center space-x-2">
                                        <span className="text-green-600">✓</span>
                                        <span className="text-sm font-medium text-green-800">
                                        Analysis Complete
                                    </span>
                                    </div>
                                </div>
                            )}

                            {error && (
                                <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg">
                                    <div className="flex items-center space-x-2">
                                        <span className="text-red-600">⚠</span>
                                        <span className="text-sm font-medium text-red-800">
                                        Error
                                    </span>
                                    </div>
                                    <div className="text-sm text-red-700 mt-1">
                                        {error}
                                    </div>
                                </div>
                            )}
                        </div>

                        <div className="text-xs text-gray-500 text-center">
                            Upload a file or enter a URL to analyze emotions using AI
                        </div>
                    </div>

                    <div className="!bg-white !rounded-2xl !shadow-xl !p-6 !w-full !max-w-md">
                        <div className="!flex !items-center !justify-between !mb-6">
                            <h3 className="!text-xl !font-bold !text-gray-800">Analysis History</h3>
                            <button
                                onClick={() => setShowHistory(!showHistory)}
                                className="!bg-transparent !text-gray-500 !hover:text-gray-700 !transition-colors !duration-200"
                            >
                                {showHistory ? '👁️‍🗨️' : '👁️'}
                            </button>
                        </div>

                        <div className="space-y-3 max-h-[600px] overflow-y-auto">
                            {analysisHistory.map((item) => (
                                <div key={item.id}
                                     className="bg-gray-50 rounded-lg p-4 hover:bg-gray-100 transition-colors duration-200">
                                    <div className="flex items-center justify-between">
                                        <div className="flex items-center space-x-3 flex-1">
                                            <span className="text-lg">{getHistoryIcon(item.type, item.source)}</span>
                                            <div className="flex-1 min-w-0">
                                                <div className="text-xs text-gray-500 mb-1">
                                                    {item.date}
                                                </div>
                                                <div className="text-sm font-medium text-gray-800 truncate max-w-[120px] overflow-hidden">
                                                    {item.name}
                                                </div>

                                            </div>
                                        </div>
                                        <button
                                            onClick={() => {
                                                setAnalysisResult(item?.result_a);
                                                setIsModalOpen(true);
                                            }}
                                            className="!ml-2 !px-3 !py-1 !bg-blue-500 !text-white !text-xs !font-medium !rounded-md !hover:bg-blue-600 !transition-colors !duration-200 !flex-shrink-0">
                                            View
                                        </button>
                                    </div>
                                </div>
                            ))}
                        </div>

                        {analysisHistory.length === 0 && (
                            <div className="text-center py-8">
                                <div className="text-4xl mb-3">📊</div>
                                <div className="text-sm text-gray-500">
                                    No analysis history yet
                                </div>
                                <div className="text-xs text-gray-400 mt-1">
                                    Start analyzing files to see your history here
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </div>
            <AnalysisResultModal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                data={analysisResult}
            />
        </>
    );
}