def validate_media_file(file):

    if not file or not file.filename:
        return {'error': 'File not selected'}

    filename = file.filename.lower()

    allowed_extensions = ['.jpg', '.jpeg', '.png', '.mp4', '.avi', '.mov', '.mkv']
    if not any(filename.endswith(ext) for ext in allowed_extensions):
        return {'error': 'Unsupported file format'}

    try:
        file.seek(0, 2)
        file_size = file.tell()
        file.seek(0)

        max_size = 50 * 1024 * 1024
        if file_size > max_size:
            return {'error': 'File is too large (maximum 50 MB)'}
    except:
        pass

    return {}