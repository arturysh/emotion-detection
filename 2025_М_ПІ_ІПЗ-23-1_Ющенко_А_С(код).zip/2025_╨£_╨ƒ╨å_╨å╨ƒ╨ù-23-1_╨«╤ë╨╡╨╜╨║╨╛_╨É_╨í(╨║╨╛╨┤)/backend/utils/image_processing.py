import cv2
import numpy as np
from PIL import Image
import io

def process_image_file(image_file, target_size=(48, 48), target_channels=1):
    try:
        if hasattr(image_file, 'seek'):
            image_file.seek(0)

        if hasattr(image_file, 'read'):
            image_bytes = image_file.read()
        else:
            image_bytes = image_file

        pil_image = Image.open(io.BytesIO(image_bytes))

        image_array = np.array(pil_image)

        if len(image_array.shape) == 3:
            if image_array.shape[2] == 4:
                image_array = cv2.cvtColor(image_array, cv2.COLOR_RGBA2RGB)
            elif image_array.shape[2] == 3:
                pass
        elif len(image_array.shape) == 2:
            pass
        else:
            raise ValueError(f"Unsupported image format: {image_array.shape}")

        if target_channels == 1:
            if len(image_array.shape) == 3:
                image_array = cv2.cvtColor(image_array, cv2.COLOR_RGB2GRAY)
        elif target_channels == 3:
            if len(image_array.shape) == 2:
                image_array = cv2.cvtColor(image_array, cv2.COLOR_GRAY2RGB)

        image_array = cv2.resize(image_array, target_size)

        image_array = image_array.astype('float32') / 255.0

        if target_channels == 1 and len(image_array.shape) == 2:
            image_array = np.expand_dims(image_array, axis=-1)

        image_array = np.expand_dims(image_array, axis=0)

        return image_array

    except Exception as e:
        raise Exception(f"Error during image processing: {str(e)}")

def process_frame_for_models(frame):
    processed_images = {}

    if len(frame.shape) == 3:
        gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    else:
        gray_frame = frame.copy()

    sizes_and_channels = [
        ((48, 48), 1),
        ((64, 64), 3),
        ((96, 96), 1),
        ((224, 224), 3),
    ]

    for (width, height), channels in sizes_and_channels:
        key = f"{width}x{height}_{channels}ch"

        if channels == 1:
            resized = cv2.resize(gray_frame, (width, height))
            resized = resized.astype('float32') / 255.0
            resized = np.expand_dims(resized, axis=-1)
        else:
            if len(frame.shape) == 3:
                rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            else:
                rgb_frame = cv2.cvtColor(frame, cv2.COLOR_GRAY2RGB)
            resized = cv2.resize(rgb_frame, (width, height))
            resized = resized.astype('float32') / 255.0

        processed_images[key] = np.expand_dims(resized, axis=0)

    return processed_images

def get_processed_image_for_model(processed_images, model_name):
    model_configs = {
        'cnn_fer2013': '48x48_1ch',
        'rnn_fer2013': '48x48_1ch',
        'vit_fer2013': '48x48_1ch',

        'cnn_raf_db': '48x48_1ch',
        'rnn_raf_db': '48x48_1ch',
        'vit_raf_db': '48x48_1ch',

        'cnn_affect_net': '48x48_1ch',
        'rnn_affect_net': '224x224_3ch',
        'vit_affect_net': '64x64_3ch',

        'cnn_affect_net_full': '48x48_1ch',
        'rnn_affect_net_full': '48x48_1ch',
        'vit_affect_net_full': '96x96_1ch',

        'pretrained_cnn_affect_net': '224x224_3ch',
        'pretrained_rnn_affect_net': '224x224_3ch',
        'pretrained_vit_affect_net': '224x224_3ch',
    }

    config_key = model_configs.get(model_name, '48x48_1ch')
    return processed_images.get(config_key, list(processed_images.values())[0])