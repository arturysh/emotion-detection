from flask import Blueprint, request, jsonify
from services.media_service import MediaService
from utils.validators import validate_media_file

predict_bp = Blueprint('predict', __name__, url_prefix='/api')

media_service = MediaService()


@predict_bp.route('/analyze', methods=['POST'])
def analyze_media():
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400

    file = request.files['file']

    validation_result = validate_media_file(file)
    if validation_result.get('error'):
        return jsonify(validation_result), 400

    try:
        result = media_service.process_media(file)
        return jsonify(result)
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@predict_bp.route('/analyze-url', methods=['POST'])
def analyze_media_url():
    data = request.get_json()

    if not data or 'url' not in data:
        return jsonify({'error': 'No URL provided'}), 400

    url = data['url']

    if not url.startswith(('http://', 'https://')):
        return jsonify({'error': 'Invalid URL format'}), 400

    try:
        results = media_service.process_media_url(url)
        return jsonify(results)
    except Exception as e:
        return jsonify({'error': str(e)}), 500