import os
import numpy as np
from tensorflow.keras.models import load_model
import tensorflow as tf
import cv2
import time
from tensorflow.keras.utils import custom_object_scope
from models.custom_layers import Patches, PatchEncoder


class ModelService:
    def __init__(self):
        self.models = {}
        self.emotion_labels = ['angry', 'disgust', 'fear', 'happy', 'neutral', 'sad', 'surprise']

        self.model_input_configs = {
            'cnn_fer2013': {'size': (48, 48), 'channels': 1},
            'rnn_fer2013': {'size': (48, 48), 'channels': 1},
            'vit_fer2013': {'size': (48, 48), 'channels': 1},

            'cnn_raf_db': {'size': (48, 48), 'channels': 1},
            'rnn_raf_db': {'size': (48, 48), 'channels': 1},
            'vit_raf_db': {'size': (48, 48), 'channels': 1},

            'cnn_affect_net': {'size': (48, 48), 'channels': 1},
            'rnn_affect_net': {'size': (224, 224), 'channels': 3},
            'vit_affect_net': {'size': (64, 64), 'channels': 3},

            'cnn_affect_net_full': {'size': (48, 48), 'channels': 1},
            'rnn_affect_net_full': {'size': (48, 48), 'channels': 1},
            'vit_affect_net_full': {'size': (96, 96), 'channels': 1},

            'pretrained_cnn_affect_net': {'size': (224, 224), 'channels': 3},
            'pretrained_rnn_affect_net': {'size': (224, 224), 'channels': 3},
            'pretrained_vit_affect_net': {'size': (224, 224), 'channels': 3},
        }

        self._load_models()

    def _load_models(self):
        """Loads all available models from models directory"""
        model_paths = {
            'cnn_raf_db': 'models/RAF-DB/improved_cnn_model.h5',
            'cnn_fer2013': 'models/FER2013/improved_cnn_model.h5',
            'cnn_affect_net': 'models/affectNet/improved_cnn_model.h5',
            'cnn_affect_net_full': 'models/affectNetPlus/improved_cnn_model.h5',
            'pretrained_cnn_affect_net': 'models/affectNet/pretrained_improved_cnn_model.h5',
            'rnn_raf_db': 'models/RAF-DB/improved_rnn_model.h5',
            'rnn_fer2013': 'models/FER2013/improved_rnn_model.h5',
            'rnn_affect_net': 'models/affectNet/improved_rnn_model.h5',
            'rnn_affect_net_full': 'models/affectNetPlus/improved_rnn_model.h5',
            'pretrained_rnn_affect_net': 'models/affectNet/pretrained_improved_rnn_model.h5',
            'vit_fer2013': 'models/FER2013/improved_vit_model.h5',
            'vit_raf_db': 'models/RAF-DB/improved_vit_model.h5',
            'vit_affect_net': 'models/affectNet/improved_vit_model.h5',
            'vit_affect_net_full': 'models/affectNetPlus/improved_vit_model.h5',
            'pretrained_vit_affect_net': 'models/affectNet/pretrained_improved_vit_model.h5',
        }

        with custom_object_scope({'Patches': Patches, 'PatchEncoder': PatchEncoder}):
            for model_name, model_path in model_paths.items():
                if os.path.exists(model_path):
                    try:
                        self.models[model_name] = load_model(model_path, compile=False)
                        print(f"Model {model_name} loaded successfully")
                    except Exception as e:
                        print(f"Error loading model {model_name}: {str(e)}")

    def _prepare_image_for_model(self, original_image, model_name):
        config = self.model_input_configs.get(model_name, {'size': (48, 48), 'channels': 1})
        target_size = config['size']
        target_channels = config['channels']

        if len(original_image.shape) == 4:
            image = original_image[0]
        else:
            image = original_image.copy()

        if len(image.shape) == 4:
            image = np.squeeze(image, axis=0)

        if target_channels == 1:
            if len(image.shape) == 3:
                if image.shape[-1] == 3:
                    image = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
                elif image.shape[-1] == 1:
                    image = np.squeeze(image, axis=-1)
        elif target_channels == 3:
            if len(image.shape) == 2:
                image = cv2.cvtColor(image, cv2.COLOR_GRAY2RGB)
            elif len(image.shape) == 3 and image.shape[-1] == 1:
                image = np.squeeze(image, axis=-1)
                image = cv2.cvtColor(image, cv2.COLOR_GRAY2RGB)

        image = cv2.resize(image, target_size)

        if image.max() > 1.0:
            image = image.astype("float32") / 255.0
        else:
            image = image.astype("float32")

        if target_channels == 1 and len(image.shape) == 2:
            image = image[..., np.newaxis]

        image = np.expand_dims(image, axis=0)

        return image

    def get_predictions(self, image):
        """
        Gets predictions from all loaded models with performance metrics
        :param image: image for analysis
        :return: dictionary with prediction results from all models and metrics
        """
        preprocessing_start = time.time()

        if hasattr(image, 'read'):
            image_bytes = image.read()
            import io
            from PIL import Image
            
            pil_image = Image.open(io.BytesIO(image_bytes))
            
            image_array = np.array(pil_image)
            
            if len(image_array.shape) == 3:
                if image_array.shape[2] == 4:
                    image_array = cv2.cvtColor(image_array, cv2.COLOR_RGBA2RGB)
                elif image_array.shape[2] == 3:
                    pass
            elif len(image_array.shape) == 2:
                pass
            else:
                raise ValueError(f"Unsupported image format: {image_array.shape}")
            
            if len(image_array.shape) == 3:
                image_array = cv2.cvtColor(image_array, cv2.COLOR_RGB2GRAY)
            
            image_array = np.expand_dims(image_array, axis=-1)
            
            base_processed_image = np.expand_dims(image_array, axis=0)
            
        else:
            if len(image.shape) == 3 and image.shape[2] == 3:
                processed = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            else:
                processed = image.copy()
            if len(processed.shape) == 4:
                processed = np.squeeze(processed, axis=0)
            if len(processed.shape) == 3 and processed.shape[2] == 1:
                processed = np.squeeze(processed, axis=2)
            if processed.max() > 1.0:
                processed = processed.astype("float32") / 255.0
            else:
                processed = processed.astype("float32")
            if len(processed.shape) == 2:
                processed = processed[..., None]
            base_processed_image = np.expand_dims(processed, axis=0)

        preprocessing_time = time.time() - preprocessing_start

        results = {}
        all_processing_times = []

        for model_name, model in self.models.items():
            model_start_time = time.time()

            try:
                model_image = self._prepare_image_for_model(base_processed_image, model_name)

                prediction = model.predict(model_image, verbose=0)

                model_processing_time = time.time() - model_start_time
                all_processing_times.append(model_processing_time)

                emotion_idx = np.argmax(prediction[0])
                emotion = self.emotion_labels[emotion_idx]
                confidence = float(prediction[0][emotion_idx])

                probabilities = {
                    label: float(prob)
                    for label, prob in zip(self.emotion_labels, prediction[0])
                }

                entropy = -np.sum(prediction[0] * np.log(prediction[0] + 1e-8))
                max_prob = np.max(prediction[0])
                second_max_prob = np.partition(prediction[0], -2)[-2]
                prediction_margin = float(max_prob - second_max_prob)

                results[model_name] = {
                    'emotion': emotion,
                    'confidence': confidence,
                    'probabilities': probabilities,
                    'metrics': {
                        'processing_time_ms': round(model_processing_time * 1000, 2),
                        'prediction_entropy': round(float(entropy), 4),
                        'prediction_margin': round(prediction_margin, 4),
                        'certainty_score': round(confidence, 4),
                        'input_shape': str(model_image.shape)
                    }
                }

            except Exception as e:
                model_processing_time = time.time() - model_start_time
                results[model_name] = {
                    'error': str(e),
                    'metrics': {
                        'processing_time_ms': round(model_processing_time * 1000, 2),
                        'failed': True
                    }
                }
                print(f"Error in model {model_name}: {str(e)}")

        successful_results = [r for r in results.values() if isinstance(r, dict) and 'error' not in r]
        total_time = sum(all_processing_times) + preprocessing_time if all_processing_times else preprocessing_time

        results['_performance_summary'] = {
            'preprocessing_time_ms': round(preprocessing_time * 1000, 2),
            'total_processing_time_ms': round(total_time * 1000, 2),
            'models_processed': len(successful_results),
            'models_failed': len(results) - len(successful_results) - 1,
            'fastest_model': min(
                [k for k, r in results.items() if k != '_performance_summary' and 'error' not in r],
                key=lambda k: results[k].get('metrics', {}).get('processing_time_ms', float('inf')),
                default=None
            ),
            'average_processing_time_ms': round(np.mean(all_processing_times) * 1000, 2) if all_processing_times else 0
        }

        return results

    def _predict_with_rnn(self, model, image):
        """Special processing for RNN model (if needed)"""
        return model.predict(image, verbose=0)