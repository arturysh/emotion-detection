import cv2
import numpy as np
import tempfile
import os
import time
from collections import Counter


class VideoProcessor:
    def __init__(self):
        self.max_frames = 15

    def extract_frames(self, video_file):
        """
        Extracts frames from video file, one frame per second
        :param video_file: video file
        :return: list of images (frames)
        """
        with tempfile.NamedTemporaryFile(delete=False, suffix='.mp4') as temp_file:
            temp_file.write(video_file.read())
            temp_filename = temp_file.name

        try:
            video_capture = cv2.VideoCapture(temp_filename)

            if not video_capture.isOpened():
                raise Exception("Failed to open video file")

            fps = video_capture.get(cv2.CAP_PROP_FPS)
            if fps <= 0:
                fps = 30

            frame_step = int(fps)

            frames = []
            frame_count = 0

            while len(frames) < self.max_frames:
                ret, frame = video_capture.read()

                if not ret:
                    break

                if frame_count % frame_step == 0:
                    frames.append(frame)

                frame_count += 1

            video_capture.release()

            return frames
        finally:
            os.unlink(temp_filename)

    def aggregate_predictions(self, frame_predictions):
        """
        Aggregates prediction results for all video frames with extended metrics
        :param frame_predictions: list of predictions for each frame
        :return: aggregated results with performance metrics
        """
        if not frame_predictions:
            return {"error": "No data for analysis"}

        def safe_mean(values):
            """Safe calculation of mean value with NaN replacement by 0"""
            if not values:
                return 0
            mean_val = np.mean(values)
            return 0 if np.isnan(mean_val) else mean_val

        def safe_std(values):
            """Safe calculation of standard deviation with NaN replacement by 0"""
            if not values:
                return 0
            std_val = np.std(values)
            return 0 if np.isnan(std_val) else std_val

        aggregated_results = {}
        models = [key for key in frame_predictions[0].keys() if key != '_performance_summary']

        for model_name in models:
            emotion_counter = Counter()

            avg_probabilities = {}

            processing_times = []
            entropy_values = []
            margin_values = []
            certainty_values = []

            valid_frames = 0

            for frame_pred in frame_predictions:
                if model_name in frame_pred and 'error' not in frame_pred[model_name]:
                    valid_frames += 1

                    emotion = frame_pred[model_name]['emotion']
                    emotion_counter[emotion] += 1

                    for emotion, prob in frame_pred[model_name]['probabilities'].items():
                        if emotion not in avg_probabilities:
                            avg_probabilities[emotion] = 0
                        avg_probabilities[emotion] += prob

                    metrics = frame_pred[model_name].get('metrics', {})
                    if metrics:
                        processing_times.append(metrics.get('processing_time_ms', 0))
                        entropy_values.append(metrics.get('prediction_entropy', 0))
                        margin_values.append(metrics.get('prediction_margin', 0))
                        certainty_values.append(metrics.get('certainty_score', 0))

            if valid_frames > 0:
                most_common_emotion = emotion_counter.most_common(1)[0][0]

                frequency = emotion_counter[most_common_emotion] / valid_frames

                for emotion in avg_probabilities:
                    avg_probabilities[emotion] /= valid_frames

                emotion_distribution = [count / valid_frames for count in emotion_counter.values()]
                try:
                    consistency_score = 1 - (-sum(p * np.log(p) for p in emotion_distribution if p > 0) / np.log(len(emotion_distribution)))
                    if np.isnan(consistency_score):
                        consistency_score = 0
                except:
                    consistency_score = 0

                aggregated_results[model_name] = {
                    'emotion': most_common_emotion,
                    'frequency': frequency,
                    'frame_count': valid_frames,
                    'emotion_counts': dict(emotion_counter),
                    'avg_probabilities': avg_probabilities,
                    'performance_metrics': {
                        'avg_processing_time_ms': round(safe_mean(processing_times), 2),
                        'total_processing_time_ms': round(sum(processing_times), 2) if processing_times else 0,
                        'min_processing_time_ms': round(min(processing_times), 2) if processing_times else 0,
                        'max_processing_time_ms': round(max(processing_times), 2) if processing_times else 0,
                        'avg_prediction_entropy': round(safe_mean(entropy_values), 4),
                        'avg_prediction_margin': round(safe_mean(margin_values), 4),
                        'avg_certainty_score': round(safe_mean(certainty_values), 4),
                        'consistency_score': round(consistency_score, 4),
                        'processing_time_std': round(safe_std(processing_times), 2)
                    }
                }
            else:
                aggregated_results[model_name] = {
                    'error': 'No successfully processed frames for this model'
                }

        valid_models = [name for name, result in aggregated_results.items()
                        if isinstance(result, dict) and 'error' not in result]

        if valid_models:
            fastest_model = min(valid_models,
                                key=lambda m: aggregated_results[m]['performance_metrics']['avg_processing_time_ms'])

            most_consistent_model = max(valid_models,
                                        key=lambda m: aggregated_results[m]['performance_metrics']['consistency_score'])

            most_confident_model = max(valid_models,
                                       key=lambda m: aggregated_results[m]['performance_metrics'][
                                           'avg_certainty_score'])

        aggregated_results['_video_summary'] = {
            'total_frames': len(frame_predictions),
            'successful_models': len(valid_models),
            'fastest_model': fastest_model if valid_models else None,
            'most_consistent_model': most_consistent_model if valid_models else None,
            'most_confident_model': most_confident_model if valid_models else None,
            'total_processing_time_ms': sum(
                result['performance_metrics']['total_processing_time_ms']
                for result in aggregated_results.values()
                if isinstance(result, dict) and 'performance_metrics' in result
            )
        }

        return aggregated_results