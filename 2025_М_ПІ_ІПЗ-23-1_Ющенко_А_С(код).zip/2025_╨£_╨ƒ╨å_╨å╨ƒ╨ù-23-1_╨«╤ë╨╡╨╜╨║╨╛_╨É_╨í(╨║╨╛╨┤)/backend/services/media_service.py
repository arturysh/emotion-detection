from services.video_processor import VideoProcessor
from services.model_service import ModelService
import cv2
import numpy as np
import mimetypes
import requests
from io import BytesIO
from werkzeug.datastructures import FileStorage
from PIL import Image
import io
import base64
from PIL.ExifTags import TAGS as ExifTags


class MediaService:
    def __init__(self):
        self.video_processor = VideoProcessor()
        self.model_service = ModelService()

    def process_media(self, file):
        """
        Processes media file (image or video)
        :param file: file to process
        :return: emotion analysis results + filename, base64 image, media type and source
        """
        filename = getattr(file, 'filename', None) or 'unknown_file'
        if self._is_video(file):
            result = self._process_video(file)
            return {
                **result,
                'filename': filename,
                'media_type': 'video',
                'source_type': 'file',
            }
        result, image_b64 = self._process_image(file, return_b64=True)
        return {
            **result,
            'filename': filename,
            'image_base64': image_b64,
            'media_type': 'image',
            'source_type': 'file',
        }

    def _is_video(self, file):
        """
        Checks if file is video
        :param file: file to check
        :return: True if file is video, False otherwise
        """
        filename = file.filename.lower()
        mime_type, _ = mimetypes.guess_type(filename)

        if mime_type and mime_type.startswith('video'):
            return True

        video_extensions = ['.mp4', '.avi', '.mov', '.mkv']
        return any(filename.endswith(ext) for ext in video_extensions)

    def _process_video(self, video_file):
        """
        Processes video file
        :param video_file: video file
        :return: dict with summary and list of frames with analysis and base64
        """
        frames = self.video_processor.extract_frames(video_file)

        if not frames:
            return {"error": "Failed to extract frames from video"}

        frame_results = []
        for frame in frames:
            predictions = self.model_service.get_predictions(frame)
            img = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
            buffered = io.BytesIO()
            img.save(buffered, format="JPEG")
            image_b64 = base64.b64encode(buffered.getvalue()).decode('utf-8')
            frame_results.append({
                'image_base64': image_b64,
                'predictions': predictions
            })

        summary = self.video_processor.aggregate_predictions([f['predictions'] for f in frame_results])

        return {
            'frames': frame_results,
            'summary': summary
        }

    def _process_image(self, image_file, return_b64=False):
        """
        Processes image
        :param image_file: image file
        :param return_b64: if True, returns base64 image
        :return: emotion analysis results and (optionally) base64
        """
        result = self.model_service.get_predictions(image_file)
        image_b64 = None
        if return_b64:
            image_file.seek(0)
            img = Image.open(image_file)
            if img.format == 'JPEG':
                try:
                    exif = img._getexif()
                    if exif is not None:
                        for tag, value in exif.items():
                            if ExifTags.TAGS.get(tag) == 'Orientation':
                                if value == 3:
                                    img = img.transpose(Image.Transpose.ROTATE_180)
                                elif value == 6:
                                    img = img.transpose(Image.Transpose.ROTATE_270)
                                elif value == 8:
                                    img = img.transpose(Image.Transpose.ROTATE_90)
                                break
                except (AttributeError, KeyError, IndexError, TypeError) as e:
                    print("Error rotating image (exif):", e)
            buffered = io.BytesIO()
            img.save(buffered, format="JPEG", exif=img.info.get('exif', b''))
            image_b64 = base64.b64encode(buffered.getvalue()).decode('utf-8')
        return result, image_b64

    def process_media_url(self, url):
        """
        Processes media file by URL
        :param url: media file URL
        :return: emotion analysis results + media type and source
        """
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }

            response = requests.get(url, timeout=30, headers=headers)
            response.raise_for_status()

            file_data = BytesIO(response.content)

            content_type = response.headers.get('content-type', '')
            filename = url.split('/')[-1] or 'media_file'

            if '.' not in filename and content_type:
                if 'image/jpeg' in content_type:
                    filename += '.jpg'
                elif 'image/png' in content_type:
                    filename += '.png'
                elif 'video/mp4' in content_type:
                    filename += '.mp4'

            file_storage = FileStorage(
                stream=file_data,
                filename=filename,
                content_type=content_type
            )

            is_video = self._is_video(file_storage)
            if is_video:
                result = self._process_video(file_storage)
                return {
                    **result,
                    'filename': filename,
                    'media_type': 'video',
                    'source_type': 'url',
                }
            result, image_b64 = self._process_image(file_storage, return_b64=True)
            return {
                **result,
                'filename': filename,
                'image_base64': image_b64,
                'media_type': 'image',
                'source_type': 'url',
            }

        except requests.RequestException as e:
            raise Exception(f"Error downloading file from URL: {str(e)}")
        except Exception as e:
            raise Exception(f"Error processing media file: {str(e)}")