from flask import Flask
from flask_cors import CORS
from config import Config
from controllers.predict_controller import predict_bp
import logging
import os


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    CORS(app)

    log_dir = os.path.join(os.getcwd(), "logs")
    os.makedirs(log_dir, exist_ok=True)
    logging.basicConfig(
        level=logging.DEBUG,
        filename=os.path.join(log_dir, "app.log"),
        format='%(asctime)s %(levelname)s %(message)s'
    )
    app.register_blueprint(predict_bp)

    return app


if __name__ == '__main__':
    app = create_app()
    app.run(debug=app.config["DEBUG"], host="0.0.0.0", port=5000)