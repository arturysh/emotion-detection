import os


class Config:
    DEBUG = True
    TESTING = False
    SECRET_KEY = os.environ.get("SECRET_KEY", "default_secret_key")

    UPLOAD_FOLDER = os.path.join(os.getcwd(), "uploads")

    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'mp4', 'avi', 'mov'}

    MAX_CONTENT_LENGTH = 16 * 1024 * 1024

    CNN_MODEL_PATH = os.path.join(os.getcwd(), "models", "cnn_model.h5")
    RNN_MODEL_PATH = os.path.join(os.getcwd(), "models", "rnn_model.h5")
    VIT_MODEL_PATH = os.path.join(os.getcwd(), "models", "vit_model.h5")