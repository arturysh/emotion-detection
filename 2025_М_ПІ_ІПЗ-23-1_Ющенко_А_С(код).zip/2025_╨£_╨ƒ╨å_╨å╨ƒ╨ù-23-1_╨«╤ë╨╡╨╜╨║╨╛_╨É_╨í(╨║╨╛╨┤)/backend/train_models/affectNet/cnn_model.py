import os
import pickle
import random
import time
import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, models, Input, regularizers
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping, ReduceLROnPlateau, TensorBoard
from sklearn.metrics import f1_score, roc_auc_score, classification_report

seed_value = 42
tf.random.set_seed(seed_value)
np.random.seed(seed_value)
random.seed(seed_value)

train_dir = "./dataset/affectNet/train"
val_dir = "./dataset/affectNet/test"

img_height, img_width = 48, 48
channels = 1
batch_size = 32
epochs = 50

train_datagen = ImageDataGenerator(
    rescale=1.0/255,
    rotation_range=25,
    zoom_range=0.25,
    shear_range=0.1,
    width_shift_range=0.1,
    height_shift_range=0.1,
    horizontal_flip=True,
    brightness_range=[0.9, 1.1],
    fill_mode="nearest"
)
val_datagen = ImageDataGenerator(rescale=1.0/255)

train_generator = train_datagen.flow_from_directory(
    train_dir,
    target_size=(img_height, img_width),
    color_mode="grayscale",
    batch_size=batch_size,
    class_mode="categorical",
    seed=seed_value
)
validation_generator = val_datagen.flow_from_directory(
    val_dir,
    target_size=(img_height, img_width),
    color_mode="grayscale",
    batch_size=batch_size,
    class_mode="categorical",
    shuffle=False,
    seed=seed_value
)

num_classes = len(train_generator.class_indices)
print("Number of classes:", num_classes)

def se_block(input_tensor, ratio=16, l2_lambda=1e-4):
    filters = input_tensor.shape[-1]
    se = layers.GlobalAveragePooling2D()(input_tensor)
    se = layers.Reshape((1, 1, filters))(se)
    se = layers.Dense(filters // ratio, activation='relu', kernel_regularizer=regularizers.l2(l2_lambda))(se)
    se = layers.Dense(filters, activation='sigmoid', kernel_regularizer=regularizers.l2(l2_lambda))(se)
    x = layers.multiply([input_tensor, se])
    return x

def residual_se_block(x, filters, kernel_size, dropout_rate, l2_lambda):
    l2_reg = regularizers.l2(l2_lambda)
    shortcut = x
    x = layers.Conv2D(filters, kernel_size, activation="relu", padding="same", kernel_regularizer=l2_reg)(x)
    x = layers.BatchNormalization()(x)
    x = layers.Conv2D(filters, kernel_size, activation="relu", padding="same", kernel_regularizer=l2_reg)(x)
    x = layers.BatchNormalization()(x)
    if shortcut.shape[-1] != filters:
        shortcut = layers.Conv2D(filters, (1, 1), padding="same", kernel_regularizer=l2_reg)(shortcut)
        shortcut = layers.BatchNormalization()(shortcut)
    x = layers.add([x, shortcut])
    x = se_block(x, l2_lambda=l2_lambda)
    x = layers.MaxPooling2D(pool_size=(2, 2))(x)
    x = layers.Dropout(dropout_rate)(x)
    return x

def build_cnn_model(input_shape, num_classes, hyperparams):
    inputs = Input(shape=input_shape)
    x = inputs
    for block in hyperparams['block_params']:
        x = residual_se_block(x, filters=block['filters'], kernel_size=block['kernel_size'], dropout_rate=block['dropout_rate'], l2_lambda=hyperparams['l2_lambda'])
    x = layers.GlobalAveragePooling2D()(x)
    x = layers.Dense(hyperparams['dense_units'], activation="relu", kernel_regularizer=regularizers.l2(hyperparams['l2_lambda']))(x)
    x = layers.BatchNormalization()(x)
    x = layers.Dropout(hyperparams['dense_dropout'])(x)
    outputs = layers.Dense(num_classes, activation="softmax")(x)
    model = models.Model(inputs, outputs)
    return model

cnn_hyperparams = {
    'block_params': [
        {'filters': 32, 'kernel_size': 3, 'dropout_rate': 0.2},
        {'filters': 64, 'kernel_size': 3, 'dropout_rate': 0.25},
        {'filters': 128, 'kernel_size': 3, 'dropout_rate': 0.3},
        {'filters': 256, 'kernel_size': 3, 'dropout_rate': 0.35},
    ],
    'dense_units': 512,
    'dense_dropout': 0.4,
    'l2_lambda': 1e-4,
}

class MetricsCallback(tf.keras.callbacks.Callback):
    def __init__(self, validation_data, batch_size):
        super(MetricsCallback, self).__init__()
        self.validation_data = validation_data
        self.batch_size = batch_size
    def on_epoch_end(self, epoch, logs=None):
        logs = logs or {}
        y_pred = self.model.predict(self.validation_data, verbose=0)
        y_true = self.validation_data.classes
        y_pred_classes = np.argmax(y_pred, axis=1)
        f1 = f1_score(y_true, y_pred_classes, average='weighted')
        try:
            y_true_onehot = tf.keras.utils.to_categorical(y_true, num_classes=y_pred.shape[1])
            roc_auc = roc_auc_score(y_true_onehot, y_pred, multi_class='ovr', average='weighted')
        except Exception as e:
            roc_auc = 0.0
        val_batch = next(iter(self.validation_data))
        start_time = time.time()
        _ = self.model.predict(val_batch[0], verbose=0)
        elapsed_time = time.time() - start_time
        latency = (elapsed_time / self.batch_size) * 1000
        throughput = self.batch_size / elapsed_time
        logs['val_f1'] = f1
        logs['val_roc_auc'] = roc_auc
        print(f"\nEpoch {epoch+1}: val_f1: {f1:.4f}, val_roc_auc: {roc_auc:.4f}")
        print(f"Latency: {latency:.2f} ms, Throughput: {throughput:.2f} images/sec")
        target_names = list(self.validation_data.class_indices.keys())
        report = classification_report(y_true, y_pred_classes, target_names=target_names, digits=4)
        print("Class-wise Performance:\n", report)

def train_model(model, train_generator, validation_generator, epochs, batch_size):
    loss_fn = tf.keras.losses.CategoricalCrossentropy(label_smoothing=0.1)
    model.compile(optimizer=Adam(learning_rate=0.001), loss=loss_fn,
                  metrics=["accuracy", tf.keras.metrics.AUC(name="auc")])
    model.summary()
    trainable_params = np.sum([tf.keras.backend.count_params(w) for w in model.trainable_weights])
    print("Total trainable parameters:", trainable_params)
    os.makedirs("./models/affectNet", exist_ok=True)
    checkpoint = ModelCheckpoint("models/affectNet/improved_cnn_model.h5", monitor="val_accuracy", verbose=1, save_best_only=True, mode="max")
    early_stop = EarlyStopping(monitor="val_accuracy", patience=10, verbose=1, mode="max")
    reduce_lr = ReduceLROnPlateau(monitor="val_loss", factor=0.5, patience=5, verbose=1, min_lr=1e-6)
    tensorboard = TensorBoard(log_dir="./logs/affectNet/cnn", histogram_freq=1)
    metrics_callback = MetricsCallback(validation_data=validation_generator, batch_size=batch_size)
    callbacks_list = [checkpoint, early_stop, reduce_lr, tensorboard, metrics_callback]
    history = model.fit(
        train_generator,
        steps_per_epoch=train_generator.samples // batch_size,
        epochs=epochs,
        validation_data=validation_generator,
        validation_steps=validation_generator.samples // batch_size,
        callbacks=callbacks_list
    )
    with open("./models/affectNet/cnn_training_history.pkl", "wb") as f:
        pickle.dump(history.history, f)
    loss, accuracy, auc = model.evaluate(validation_generator, steps=validation_generator.samples // batch_size)
    print("Validation Accuracy: {:.2f}%".format(accuracy * 100))
    print("Validation AUC: {:.4f}".format(auc))
    model.save("models/affectNet/improved_cnn_model_final.h5")
    return history

input_shape = (img_height, img_width, channels)
cnn_model = build_cnn_model(input_shape, num_classes, cnn_hyperparams)
history = train_model(cnn_model, train_generator, validation_generator, epochs, batch_size)