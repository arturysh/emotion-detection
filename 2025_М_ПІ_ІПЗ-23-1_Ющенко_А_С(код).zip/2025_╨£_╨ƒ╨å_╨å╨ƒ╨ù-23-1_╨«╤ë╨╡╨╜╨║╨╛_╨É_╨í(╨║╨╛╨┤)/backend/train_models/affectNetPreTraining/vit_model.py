import os
import pickle
import random
import time
import numpy as np
import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Dense, Dropout, GlobalAveragePooling2D, BatchNormalization
from tensorflow.keras.optimizers import Adam, AdamW
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping, TensorBoard, ReduceLROnPlateau
from sklearn.metrics import classification_report, confusion_matrix, f1_score, roc_auc_score
from sklearn.utils.class_weight import compute_class_weight
import matplotlib.pyplot as plt
import seaborn as sns

try:
    from transformers import TFViTModel, ViTConfig
    from transformers import ViTImageProcessor

    HUGGINGFACE_AVAILABLE = True

except ImportError:

    HUGGINGFACE_AVAILABLE = False

    exit(1)

seed_value = 42
tf.random.set_seed(seed_value)
np.random.seed(seed_value)
random.seed(seed_value)

train_dir = "./dataset/affectNet/train"
val_dir = "./dataset/affectNet/test"

img_height, img_width = 224, 224
batch_size = 16
epochs = 50
initial_learning_rate = 0.0001

train_datagen = ImageDataGenerator(
    rescale=1.0 / 255,
    rotation_range=25,
    zoom_range=0.15,
    width_shift_range=0.15,
    height_shift_range=0.15,
    horizontal_flip=True,
    brightness_range=[0.8, 1.2],
    shear_range=0.1,
    channel_shift_range=0.1,
    fill_mode='nearest'
)

val_datagen = ImageDataGenerator(rescale=1.0 / 255)

color_mode = "rgb"

train_generator = train_datagen.flow_from_directory(
    train_dir,
    target_size=(img_height, img_width),
    color_mode=color_mode,
    batch_size=batch_size,
    class_mode="categorical",
    shuffle=True,
    seed=seed_value
)

validation_generator = val_datagen.flow_from_directory(
    val_dir,
    target_size=(img_height, img_width),
    color_mode=color_mode,
    batch_size=batch_size,
    class_mode="categorical",
    shuffle=False,
    seed=seed_value
)

class_indices = train_generator.class_indices
num_classes = len(class_indices)
print("Classes:", class_indices)
print(f"Classes num: {num_classes}")

class_weights = compute_class_weight(
    'balanced',
    classes=np.unique(train_generator.classes),
    y=train_generator.classes
)
class_weight_dict = dict(enumerate(class_weights))
print("Classes weight:", class_weight_dict)


class ImprovedViTForImageClassification(tf.keras.Model):
    def __init__(self, num_classes, model_name="google/vit-base-patch16-224-in21k", **kwargs):
        super().__init__(**kwargs)
        self.num_classes = num_classes

        self.vit = TFViTModel.from_pretrained(model_name)

        self.vit.trainable = True

        self._freeze_vit_layers(freeze_ratio=0.5)

        self.global_pool = GlobalAveragePooling2D()
        self.dropout1 = Dropout(0.4)
        self.batch_norm1 = BatchNormalization()
        self.dense1 = Dense(1024, activation='relu')

        self.dropout2 = Dropout(0.3)
        self.batch_norm2 = BatchNormalization()
        self.dense2 = Dense(512, activation='relu')

        self.dropout3 = Dropout(0.2)
        self.batch_norm3 = BatchNormalization()
        self.dense3 = Dense(256, activation='relu')

        self.classifier = Dense(num_classes, activation='softmax')

    def _freeze_vit_layers(self, freeze_ratio=0.5):
        all_layers = []

        def collect_layers(layer, prefix=""):
            if hasattr(layer, 'layers'):
                for i, sublayer in enumerate(layer.layers):
                    collect_layers(sublayer, f"{prefix}.layer_{i}")
            elif hasattr(layer, 'trainable'):
                all_layers.append(layer)

        collect_layers(self.vit)

        if all_layers:
            freeze_count = int(len(all_layers) * freeze_ratio)
            for i, layer in enumerate(all_layers):
                if i < freeze_count:
                    layer.trainable = False
                else:
                    layer.trainable = True

            print(f"Froze {freeze_count}  {len(all_layers)} slice ViT ({freeze_ratio * 100:.0f}%)")
        else:
            print("Error slice.")

    def unfreeze_vit_layers(self, unfreeze_ratio=1.0):
        all_layers = []

        def collect_layers(layer):
            if hasattr(layer, 'layers'):
                for sublayer in layer.layers:
                    collect_layers(sublayer)
            elif hasattr(layer, 'trainable'):
                all_layers.append(layer)

        collect_layers(self.vit)

        if all_layers:
            unfreeze_count = int(len(all_layers) * unfreeze_ratio)
            unfrozen = 0

            for layer in reversed(all_layers):
                if unfrozen < unfreeze_count:
                    layer.trainable = True
                    unfrozen += 1
                else:
                    layer.trainable = False

            print(f"Unfroze {unfrozen}  {len(all_layers)} slice ViT ({unfreeze_ratio * 100:.0f}%)")

    def call(self, inputs, training=None):
        pixel_values = tf.transpose(inputs, [0, 3, 1, 2])

        vit_outputs = self.vit(pixel_values=pixel_values, training=training)

        cls_token = vit_outputs.last_hidden_state[:, 0, :]

        x = self.dropout1(cls_token, training=training)
        x = self.batch_norm1(x, training=training)
        x = self.dense1(x)

        x = self.dropout2(x, training=training)
        x = self.batch_norm2(x, training=training)
        x = self.dense2(x)

        x = self.dropout3(x, training=training)
        x = self.batch_norm3(x, training=training)
        x = self.dense3(x)

        outputs = self.classifier(x)
        return outputs

    def get_config(self):
        config = super().get_config()
        config.update({
            "num_classes": self.num_classes
        })
        return config


def explore_vit_structure(model):

    for attr in dir(model):
        if not attr.startswith('_'):
            try:
                obj = getattr(model, attr)
                if hasattr(obj, 'layers') or hasattr(obj, 'trainable'):
                    print(f"  {attr}: {type(obj)}")
            except:
                pass

    if hasattr(model, 'vit'):
        vit_inner = model.vit
        for attr in dir(vit_inner):
            if not attr.startswith('_'):
                try:
                    obj = getattr(vit_inner, attr)
                    if hasattr(obj, 'layers') or hasattr(obj, 'trainable'):
                        print(f"  vit.{attr}: {type(obj)}")

                        if attr == 'encoder' and hasattr(obj, 'layer'):
                            print(f"    encoder содержит {len(obj.layer)} слоев")
                except:
                    pass

    def find_transformer_layers(obj, path=""):
        layers_found = []
        for attr in dir(obj):
            if not attr.startswith('_'):
                try:
                    child = getattr(obj, attr)
                    current_path = f"{path}.{attr}" if path else attr

                    if hasattr(child, 'layer') and hasattr(child, '__len__'):
                        layers_found.append((current_path, len(child.layer)))
                    elif hasattr(child, 'layers') and hasattr(child, '__len__'):
                        layers_found.append((current_path, len(child.layers)))
                    elif hasattr(child, 'trainable') and len(path.split('.')) < 3:
                        layers_found.extend(find_transformer_layers(child, current_path))
                except:
                    pass
        return layers_found

    transformer_layers = find_transformer_layers(model)
    if transformer_layers:
        for path, count in transformer_layers:
            print(f"  {path}: {count} slice")

    return transformer_layers


def build_improved_vit_model(num_classes, model_name="google/vit-base-patch16-224-in21k"):
    try:
        model = ImprovedViTForImageClassification(num_classes=num_classes, model_name=model_name)

        dummy_input = tf.random.normal((1, img_height, img_width, 3))
        _ = model(dummy_input)

        print("\n" + "=" * 50)
        explore_vit_structure(model.vit)
        print("=" * 50)

        return model

    except Exception as e:
        print(f"Error {model_name}: {e}")
        raise e


vit_model = build_improved_vit_model(num_classes)


def cosine_decay_with_warmup(epoch, lr):
    warmup_epochs = 5
    total_epochs = epochs

    if epoch < warmup_epochs:
        return initial_learning_rate * (epoch + 1) / warmup_epochs
    else:
        progress = (epoch - warmup_epochs) / (total_epochs - warmup_epochs)
        return initial_learning_rate * 0.5 * (1 + np.cos(np.pi * progress))


lr_scheduler = tf.keras.callbacks.LearningRateScheduler(cosine_decay_with_warmup)

optimizer = AdamW(learning_rate=initial_learning_rate, weight_decay=0.01)

class FocalLoss(tf.keras.losses.Loss):
    def __init__(self, alpha=1.0, gamma=2.0, **kwargs):
        super().__init__(**kwargs)
        self.alpha = alpha
        self.gamma = gamma

    def call(self, y_true, y_pred):
        y_pred = tf.clip_by_value(y_pred, 1e-8, 1.0 - 1e-8)

        ce_loss = -y_true * tf.math.log(y_pred)
        p_t = y_true * y_pred + (1 - y_true) * (1 - y_pred)
        focal_weight = self.alpha * tf.pow(1 - p_t, self.gamma)
        focal_loss = focal_weight * ce_loss

        return tf.reduce_sum(focal_loss, axis=-1)


class ImprovedMetricsCallback(tf.keras.callbacks.Callback):
    def __init__(self, validation_data, batch_size):
        super().__init__()
        self.validation_data = validation_data
        self.batch_size = batch_size
        self.best_f1 = 0

    def on_epoch_end(self, epoch, logs=None):
        logs = logs or {}

        self.validation_data.reset()

        y_pred = self.model.predict(self.validation_data, verbose=0)
        y_true = self.validation_data.classes
        y_pred_classes = np.argmax(y_pred, axis=1)

        f1_weighted = f1_score(y_true, y_pred_classes, average='weighted')
        f1_macro = f1_score(y_true, y_pred_classes, average='macro')

        try:
            y_true_onehot = tf.keras.utils.to_categorical(y_true, num_classes=y_pred.shape[1])
            roc_auc = roc_auc_score(y_true_onehot, y_pred, multi_class='ovr', average='weighted')
        except Exception as e:
            roc_auc = 0.0

        logs['val_f1_weighted'] = f1_weighted
        logs['val_f1_macro'] = f1_macro
        logs['val_roc_auc'] = roc_auc

        if f1_weighted > self.best_f1:
            self.best_f1 = f1_weighted
            self.model.save_weights("models/affectNet/best_f1_weights.weights.h5")

        print(f"\nEpoch {epoch + 1}:")
        print(f"val_f1_weighted: {f1_weighted:.4f}, val_f1_macro: {f1_macro:.4f}")
        print(f"val_roc_auc: {roc_auc:.4f}, best_f1: {self.best_f1:.4f}")


vit_model.compile(
    optimizer=optimizer,
    loss=FocalLoss(alpha=1.0, gamma=2.0),
    metrics=['accuracy', tf.keras.metrics.AUC(name="auc")]
)



total_params = vit_model.count_params()
trainable_params = sum([tf.size(var).numpy() for var in vit_model.trainable_variables])
frozen_params = total_params - trainable_params



os.makedirs("./models/affectNet", exist_ok=True)

metrics_callback = ImprovedMetricsCallback(validation_data=validation_generator, batch_size=batch_size)

checkpoint = ModelCheckpoint(
    "models/affectNet/improved_vit_model.weights.h5",
    monitor='val_accuracy',
    save_best_only=True,
    mode='max',
    verbose=1,
    save_weights_only=True
)

early_stop = EarlyStopping(
    monitor='val_f1_weighted',
    patience=15,
    restore_best_weights=True,
    verbose=1,
    mode='max'
)

reduce_lr = ReduceLROnPlateau(
    monitor='val_loss',
    factor=0.5,
    patience=5,
    min_lr=1e-7,
    verbose=1
)

tensorboard = TensorBoard(log_dir="./logs/affectNet/improved_vit", histogram_freq=1)

callbacks = [metrics_callback, checkpoint, early_stop, reduce_lr, lr_scheduler, tensorboard]


vit_model.vit.trainable = False
vit_model.compile(
    optimizer=AdamW(learning_rate=initial_learning_rate),
    loss=FocalLoss(alpha=1.0, gamma=2.0),
    metrics=['accuracy', tf.keras.metrics.AUC(name="auc")]
)

stage1_callbacks = [reduce_lr, metrics_callback]

history_stage1 = vit_model.fit(
    train_generator,
    steps_per_epoch=train_generator.samples // batch_size,
    epochs=15,
    validation_data=validation_generator,
    validation_steps=validation_generator.samples // batch_size,
    class_weight=class_weight_dict,
    callbacks=stage1_callbacks,
    verbose=1
)

vit_model.unfreeze_vit_layers(unfreeze_ratio=0.7)

vit_model.compile(
    optimizer=AdamW(learning_rate=initial_learning_rate / 5),
    loss=FocalLoss(alpha=1.0, gamma=2.0),
    metrics=['accuracy', tf.keras.metrics.AUC(name="auc")]
)

history_stage2 = vit_model.fit(
    train_generator,
    steps_per_epoch=train_generator.samples // batch_size,
    epochs=20,
    validation_data=validation_generator,
    validation_steps=validation_generator.samples // batch_size,
    class_weight=class_weight_dict,
    callbacks=callbacks,
    verbose=1
)

if hasattr(vit_model.vit, 'vit') and hasattr(vit_model.vit.vit, 'encoder'):
    for layer in vit_model.vit.vit.encoder.layer:
        layer.trainable = True
else:
    vit_model.vit.trainable = True

vit_model.compile(
    optimizer=AdamW(learning_rate=initial_learning_rate / 10),
    loss=FocalLoss(alpha=1.0, gamma=2.0),
    metrics=['accuracy', tf.keras.metrics.AUC(name="auc")]
)

history_stage3 = vit_model.fit(
    train_generator,
    steps_per_epoch=train_generator.samples // batch_size,
    epochs=15,
    validation_data=validation_generator,
    validation_steps=validation_generator.samples // batch_size,
    class_weight=class_weight_dict,
    callbacks=callbacks,
    verbose=1
)

try:
    vit_model.load_weights("models/affectNet/best_f1_weights.weights.h5")
except:
    print("Error weight")

validation_generator.reset()
val_loss, val_accuracy, val_auc = vit_model.evaluate(
    validation_generator,
    steps=validation_generator.samples // batch_size
)

print(f"Final Validation Accuracy: {val_accuracy * 100:.2f}%")
print(f"Final Validation AUC: {val_auc:.4f}")

validation_generator.reset()
y_pred = vit_model.predict(validation_generator, verbose=1)
y_pred_classes = np.argmax(y_pred, axis=1)
y_true = validation_generator.classes

print("\nClassification Report:")
print(classification_report(y_true, y_pred_classes, target_names=list(class_indices.keys())))

f1_weighted = f1_score(y_true, y_pred_classes, average='weighted')
f1_macro = f1_score(y_true, y_pred_classes, average='macro')
print(f"\nF1 Score (weighted): {f1_weighted:.4f}")
print(f"F1 Score (macro): {f1_macro:.4f}")

try:
    vit_model.save_weights("models/affectNet/final_improved_vit_model.weights.h5")
except Exception as e:
    print(f"Error weight: {e}")

    try:
        vit_model.save("models/affectNet/final_improved_vit_model", save_format='tf')
        print("Saved TensorFlow SavedModel!")
    except Exception as e2:
        print(f"Error saved: {e2}")

print(f"Accuracy: {val_accuracy * 100:.1f}%")