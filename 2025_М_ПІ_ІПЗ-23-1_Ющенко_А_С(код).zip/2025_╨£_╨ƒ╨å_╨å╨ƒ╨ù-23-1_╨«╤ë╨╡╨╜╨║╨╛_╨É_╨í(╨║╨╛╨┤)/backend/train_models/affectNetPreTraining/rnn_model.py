import os
import pickle
import random
import time
import numpy as np
import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Dense, Dropout, Reshape, Bidirectional, LSTM, BatchNormalization
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping, TensorBoard
from tensorflow.keras.applications import ResNet50
from tensorflow.keras.regularizers import l2
from sklearn.metrics import classification_report, confusion_matrix, f1_score, roc_auc_score
import matplotlib.pyplot as plt
import seaborn as sns

seed_value = 42
tf.random.set_seed(seed_value)
np.random.seed(seed_value)
random.seed(seed_value)

train_dir = "./dataset/affectNet/train"
val_dir = "./dataset/affectNet/test"

img_height, img_width = 224, 224
batch_size = 16
epochs = 30
initial_learning_rate = 0.00001


train_datagen = ImageDataGenerator(
    rescale=1.0 / 255,
    rotation_range=15,
    zoom_range=0.1,
    width_shift_range=0.1,
    height_shift_range=0.1,
    horizontal_flip=True,
    fill_mode='nearest'
)
val_datagen = ImageDataGenerator(rescale=1.0 / 255)

color_mode = "rgb"

train_generator = train_datagen.flow_from_directory(
    train_dir,
    target_size=(img_height, img_width),
    color_mode=color_mode,
    batch_size=batch_size,
    class_mode="categorical",
    shuffle=True,
    seed=seed_value
)

validation_generator = val_datagen.flow_from_directory(
    val_dir,
    target_size=(img_height, img_width),
    color_mode=color_mode,
    batch_size=batch_size,
    class_mode="categorical",
    shuffle=False,
    seed=seed_value
)

class_indices = train_generator.class_indices
num_classes = len(class_indices)
print("Классы:", class_indices)
print(f"Количество классов: {num_classes}")

# Гиперпараметры для RNN части (адаптированные под предобученную модель)
rnn_hyperparams = {
    'rnn_layers': [
        {'units': 256, 'bidirectional': True, 'dropout': 0.3, 'return_sequences': True},
        {'units': 128, 'bidirectional': True, 'dropout': 0.4, 'return_sequences': False}
    ],
    'dense_units': 512,
    'dense_dropout': 0.3,
    'l2_lambda': 1e-4
}


def build_pretrained_cnn_rnn_model(num_classes, hyperparams):
    """Создание гибридной CNN-RNN модели с предобученным ResNet50"""

    # Загружаем предобученную ResNet50 (без классификационной головы)
    base_model = ResNet50(
        weights='imagenet',
        include_top=False,
        input_shape=(img_height, img_width, 3)
    )

    # Замораживаем базовую модель (аналогично CNN и ViT)
    base_model.trainable = False

    # Создаем модель
    inputs = Input(shape=(img_height, img_width, 3))

    # Пропускаем через предобученный CNN
    x = base_model(inputs, training=False)
    # x имеет форму (batch_size, 7, 7, 2048) для ResNet50

    # Преобразуем feature maps в последовательность для RNN
    # Каждый пространственный элемент (7x7) становится временным шагом
    # ИСПРАВЛЕНИЕ: Используем известные размеры вместо tf.shape()
    height, width, channels = 7, 7, 2048  # Известные размеры выхода ResNet50

    # Reshape: (batch, 7, 7, 2048) -> (batch, 7*7, 2048)
    # Трактуем каждую позицию (i,j) как временной шаг
    x = Reshape((height * width, channels))(x)

    # Добавляем RNN слои
    for layer_params in hyperparams['rnn_layers']:
        if layer_params['bidirectional']:
            x = Bidirectional(
                LSTM(
                    layer_params['units'],
                    return_sequences=layer_params['return_sequences'],
                    kernel_regularizer=l2(hyperparams['l2_lambda'])
                )
            )(x)
        else:
            x = LSTM(
                layer_params['units'],
                return_sequences=layer_params['return_sequences'],
                kernel_regularizer=l2(hyperparams['l2_lambda'])
            )(x)
        x = Dropout(layer_params['dropout'])(x)

    # Классификационная голова (идентичная CNN и ViT)
    x = Dense(hyperparams['dense_units'], activation='relu',
              kernel_regularizer=l2(hyperparams['l2_lambda']))(x)
    x = BatchNormalization()(x)
    x = Dropout(hyperparams['dense_dropout'])(x)
    x = Dense(256, activation='relu')(x)
    outputs = Dense(num_classes, activation='softmax')(x)

    model = Model(inputs, outputs)

    return model, base_model


# Создание модели
cnn_rnn_model, base_model = build_pretrained_cnn_rnn_model(num_classes, rnn_hyperparams)
print("Используется предобученная ResNet50 + RNN модель")

# Настройка оптимизатора и компиляция (идентично CNN и ViT)
lr_schedule = tf.keras.optimizers.schedules.ExponentialDecay(
    initial_learning_rate=initial_learning_rate,
    decay_steps=1000,
    decay_rate=0.9,
    staircase=True
)

optimizer = Adam(learning_rate=lr_schedule)
loss_fn = tf.keras.losses.CategoricalCrossentropy(label_smoothing=0.1)
cnn_rnn_model.compile(
    optimizer=optimizer,
    loss=loss_fn,
    metrics=['accuracy', tf.keras.metrics.AUC(name="auc")]
)

print("Архитектура модели:")
print(f"Входные данные: {img_height}x{img_width}x3")
print(f"Количество классов: {num_classes}")
print(f"Batch size: {batch_size}")

# Показать количество параметров
total_params = cnn_rnn_model.count_params()
trainable_params = sum([tf.size(var).numpy() for var in cnn_rnn_model.trainable_variables])
frozen_params = total_params - trainable_params

print(f"\nПараметры модели:")
print(f"Всего параметров: {total_params:,}")
print(f"Обучаемых параметров: {trainable_params:,}")
print(f"Замороженных параметров: {frozen_params:,}")

# Показать архитектуру
cnn_rnn_model.summary()


class MetricsCallback(tf.keras.callbacks.Callback):
    """Идентичный callback как в CNN и ViT"""

    def __init__(self, validation_data, batch_size):
        super(MetricsCallback, self).__init__()
        self.validation_data = validation_data
        self.batch_size = batch_size

    def on_epoch_end(self, epoch, logs=None):
        logs = logs or {}

        # Сброс генератора
        self.validation_data.reset()

        # Предсказания
        y_pred = self.model.predict(self.validation_data, verbose=0)
        y_true = self.validation_data.classes
        y_pred_classes = np.argmax(y_pred, axis=1)

        # Вычисление метрик
        f1 = f1_score(y_true, y_pred_classes, average='weighted')

        try:
            y_true_onehot = tf.keras.utils.to_categorical(y_true, num_classes=y_pred.shape[1])
            roc_auc = roc_auc_score(y_true_onehot, y_pred, multi_class='ovr', average='weighted')
        except Exception as e:
            roc_auc = 0.0

        # Измерение производительности
        val_batch = next(iter(self.validation_data))
        start_time = time.time()
        _ = self.model.predict(val_batch[0], verbose=0)
        elapsed_time = time.time() - start_time
        latency = (elapsed_time / len(val_batch[0])) * 1000
        throughput = len(val_batch[0]) / elapsed_time

        logs['val_f1'] = f1
        logs['val_roc_auc'] = roc_auc

        print(f"\nEpoch {epoch + 1}: val_f1: {f1:.4f}, val_roc_auc: {roc_auc:.4f}")
        print(f"Latency: {latency:.2f} ms, Throughput: {throughput:.2f} images/sec")


# Настройка callbacks (идентично CNN и ViT)
os.makedirs("./models/affectNetPreTraining", exist_ok=True)
checkpoint = ModelCheckpoint(
    "models/affectNetPreTraining/pretrained_cnn_rnn_model.h5",
    monitor='val_accuracy',
    save_best_only=True,
    mode='max',
    verbose=1
)
early_stop = EarlyStopping(
    monitor='val_accuracy',
    patience=8,
    restore_best_weights=True,
    verbose=1
)
tensorboard = TensorBoard(log_dir="./logs/affectNetPreTraining/pretrained_cnn_rnn", histogram_freq=1)
metrics_callback = MetricsCallback(validation_data=validation_generator, batch_size=batch_size)

callbacks = [checkpoint, early_stop, tensorboard, metrics_callback]

# Обучение модели
print("Начинаем обучение...")
history = cnn_rnn_model.fit(
    train_generator,
    steps_per_epoch=train_generator.samples // batch_size,
    epochs=epochs,
    validation_data=validation_generator,
    validation_steps=validation_generator.samples // batch_size,
    callbacks=callbacks,
    verbose=1
)

# Сохранение истории обучения
with open("./models/affectNetPreTraining/pretrained_cnn_rnn_training_history.pkl", "wb") as f:
    pickle.dump(history.history, f)

# Финальная оценка
print("\nФинальная оценка модели...")
validation_generator.reset()
val_loss, val_accuracy, val_auc = cnn_rnn_model.evaluate(
    validation_generator,
    steps=validation_generator.samples // batch_size
)

print(f"Validation Accuracy: {val_accuracy * 100:.2f}%")
print(f"Validation AUC: {val_auc:.4f}")

# Получение предсказаний для детального анализа
validation_generator.reset()
y_pred = cnn_rnn_model.predict(validation_generator, verbose=1)
y_pred_classes = np.argmax(y_pred, axis=1)
y_true = validation_generator.classes

# Отчет о классификации
print("\nClassification Report:")
print(classification_report(y_true, y_pred_classes, target_names=list(class_indices.keys())))

# Матрица ошибок
plt.figure(figsize=(12, 10))
cm = confusion_matrix(y_true, y_pred_classes)
sns.heatmap(
    cm,
    annot=True,
    fmt='d',
    xticklabels=list(class_indices.keys()),
    yticklabels=list(class_indices.keys()),
    cmap='Blues'
)
plt.title('Confusion Matrix - Pretrained CNN-RNN (ResNet50 + LSTM)')
plt.xlabel('Predicted Classes')
plt.ylabel('True Classes')
plt.tight_layout()
plt.savefig('pretrained_cnn_rnn_confusion_matrix.png', dpi=300, bbox_inches='tight')
plt.show()

# Графики обучения (идентично CNN и ViT)
fig, axes = plt.subplots(2, 2, figsize=(15, 10))

# Accuracy
axes[0, 0].plot(history.history['accuracy'], label='Training Accuracy')
axes[0, 0].plot(history.history['val_accuracy'], label='Validation Accuracy')
axes[0, 0].set_title('Model Accuracy')
axes[0, 0].set_xlabel('Epoch')
axes[0, 0].set_ylabel('Accuracy')
axes[0, 0].legend()

# Loss
axes[0, 1].plot(history.history['loss'], label='Training Loss')
axes[0, 1].plot(history.history['val_loss'], label='Validation Loss')
axes[0, 1].set_title('Model Loss')
axes[0, 1].set_xlabel('Epoch')
axes[0, 1].set_ylabel('Loss')
axes[0, 1].legend()

# AUC
axes[1, 0].plot(history.history['auc'], label='Training AUC')
axes[1, 0].plot(history.history['val_auc'], label='Validation AUC')
axes[1, 0].set_title('Model AUC')
axes[1, 0].set_xlabel('Epoch')
axes[1, 0].set_ylabel('AUC')
axes[1, 0].legend()

# F1 Score (если доступно)
if 'val_f1' in history.history:
    axes[1, 1].plot(history.history['val_f1'], label='Validation F1')
    axes[1, 1].set_title('F1 Score')
    axes[1, 1].set_xlabel('Epoch')
    axes[1, 1].set_ylabel('F1 Score')
    axes[1, 1].legend()

plt.tight_layout()
plt.savefig('pretrained_cnn_rnn_training_history.png', dpi=300, bbox_inches='tight')
plt.show()

# Сохранение финальной модели
cnn_rnn_model.save("models/affectNetPreTraining/final_pretrained_cnn_rnn_model.h5")
print("Модель сохранена!")

# Опциональная разморозка и дообучение (идентично CNN и ViT)
print("\n" + "=" * 50)
print("ОПЦИОНАЛЬНАЯ РАЗМОРОЗКА МОДЕЛИ ДЛЯ FINE-TUNING")
print("=" * 50)

fine_tune = input("Хотите провести fine-tuning с разморозкой слоев? (y/n): ").lower() == 'y'

if fine_tune:
    # Размораживаем базовую модель для fine-tuning
    base_model.trainable = True

    # Замораживаем только начальные слои, размораживаем последние
    # ResNet50 имеет 5 блоков, замораживаем первые 3
    for layer in base_model.layers[:-30]:  # Замораживаем все кроме последних 30 слоев
        layer.trainable = False

    # Компилируем с меньшим learning rate (как в CNN и ViT)
    cnn_rnn_model.compile(
        optimizer=Adam(learning_rate=initial_learning_rate / 10),
        loss=loss_fn,
        metrics=['accuracy', tf.keras.metrics.AUC(name="auc")]
    )

    print("Начинаем fine-tuning...")

    # Обучаем еще несколько эпох
    fine_tune_epochs = 10
    total_epochs = len(history.history['loss']) + fine_tune_epochs

    history_fine = cnn_rnn_model.fit(
        train_generator,
        steps_per_epoch=train_generator.samples // batch_size,
        epochs=total_epochs,
        initial_epoch=len(history.history['loss']),
        validation_data=validation_generator,
        validation_steps=validation_generator.samples // batch_size,
        callbacks=[checkpoint, early_stop, metrics_callback],
        verbose=1
    )

    # Сохраняем fine-tuned модель
    cnn_rnn_model.save("models/affectNetPreTraining/fine_tuned_cnn_rnn_model.h5")

    # Финальная оценка после fine-tuning
    validation_generator.reset()
    val_loss, val_accuracy, val_auc = cnn_rnn_model.evaluate(
        validation_generator,
        steps=validation_generator.samples // batch_size
    )

    print(f"Final Fine-tuned Validation Accuracy: {val_accuracy * 100:.2f}%")
    print(f"Final Fine-tuned Validation AUC: {val_auc:.4f}")

print("\nОбучение завершено!")

# Дополнительный анализ производительности для сравнения с CNN и ViT
print("\n" + "=" * 50)
print("АНАЛИЗ ПРОИЗВОДИТЕЛЬНОСТИ")
print("=" * 50)

# Измерение времени инференса
validation_generator.reset()
test_batch = next(iter(validation_generator))
test_images = test_batch[0]

# Прогрев модели
_ = cnn_rnn_model.predict(test_images[:1], verbose=0)

# Измерение времени
inference_times = []
for i in range(10):
    start_time = time.time()
    _ = cnn_rnn_model.predict(test_images, verbose=0)
    inference_times.append(time.time() - start_time)

avg_inference_time = np.mean(inference_times)
avg_latency = (avg_inference_time / len(test_images)) * 1000
avg_throughput = len(test_images) / avg_inference_time

print(f"Средняя латентность: {avg_latency:.2f} ms на изображение")
print(f"Средняя пропускная способность: {avg_throughput:.2f} изображений/сек")
print(f"Размер batch: {len(test_images)}")

# Сравнение с параметрами модели
print(f"\nСравнение архитектур:")
print(f"CNN-RNN (ResNet50+LSTM) - Параметров: {total_params:,}")
print(f"CNN-RNN (ResNet50+LSTM) - Обучаемых: {trainable_params:,}")
print(f"CNN-RNN (ResNet50+LSTM) - Замороженных: {frozen_params:,}")

# Дополнительная информация о RNN части
print(f"\nДетали RNN архитектуры:")
print(f"Входная последовательность для RNN: 49 шагов (7x7 feature map)")
print(f"Размер features на каждом шаге: 2048 (из ResNet50)")
print(f"RNN слои: {len(rnn_hyperparams['rnn_layers'])}")
for i, layer in enumerate(rnn_hyperparams['rnn_layers']):
    direction = "Bidirectional" if layer['bidirectional'] else "Unidirectional"
    print(f"  Слой {i + 1}: {direction} LSTM, {layer['units']} units, dropout {layer['dropout']}")