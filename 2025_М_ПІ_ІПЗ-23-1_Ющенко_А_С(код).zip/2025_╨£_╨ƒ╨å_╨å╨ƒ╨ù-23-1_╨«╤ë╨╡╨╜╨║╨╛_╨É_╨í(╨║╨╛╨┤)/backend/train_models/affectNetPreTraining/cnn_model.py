import os
import pickle
import random
import time
import numpy as np
import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Dense, Dropout, GlobalAveragePooling2D
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping, TensorBoard
from tensorflow.keras.applications import EfficientNetB0, ResNet50, VGG16
from sklearn.metrics import classification_report, confusion_matrix, f1_score, roc_auc_score
import matplotlib.pyplot as plt
import seaborn as sns

# Установка seed для воспроизводимости
seed_value = 42
tf.random.set_seed(seed_value)
np.random.seed(seed_value)
random.seed(seed_value)

# Конфигурация (копируем настройки из ViT)
train_dir = "./dataset/affectNet/train"
val_dir = "./dataset/affectNet/test"

# Используем те же размеры изображений что и в ViT
img_height, img_width = 224, 224
batch_size = 16  # Тот же batch_size что и в ViT
epochs = 30  # Те же количество эпох
initial_learning_rate = 0.00001  # Тот же learning rate для fine-tuning

# Настройка генераторов данных для RGB изображений (как в ViT)
train_datagen = ImageDataGenerator(
    rescale=1.0 / 255,
    rotation_range=15,
    zoom_range=0.1,
    width_shift_range=0.1,
    height_shift_range=0.1,
    horizontal_flip=True,
    fill_mode='nearest'
)
val_datagen = ImageDataGenerator(rescale=1.0 / 255)

color_mode = "rgb"  # RGB как в ViT

train_generator = train_datagen.flow_from_directory(
    train_dir,
    target_size=(img_height, img_width),
    color_mode=color_mode,
    batch_size=batch_size,
    class_mode="categorical",
    shuffle=True,
    seed=seed_value
)

validation_generator = val_datagen.flow_from_directory(
    val_dir,
    target_size=(img_height, img_width),
    color_mode=color_mode,
    batch_size=batch_size,
    class_mode="categorical",
    shuffle=False,
    seed=seed_value
)

class_indices = train_generator.class_indices
num_classes = len(class_indices)
print("Классы:", class_indices)
print(f"Количество классов: {num_classes}")


class CNNForImageClassification(tf.keras.Model):
    """Кастомная модель CNN для классификации изображений с предобученным backbone"""

    def __init__(self, num_classes, backbone_name="efficientnet", **kwargs):
        super().__init__(**kwargs)
        self.num_classes = num_classes
        self.backbone_name = backbone_name

        # Загружаем предобученную модель
        if backbone_name == "efficientnet":
            self.backbone = EfficientNetB0(
                weights='imagenet',
                include_top=False,
                input_shape=(img_height, img_width, 3)
            )
        elif backbone_name == "resnet50":
            self.backbone = ResNet50(
                weights='imagenet',
                include_top=False,
                input_shape=(img_height, img_width, 3)
            )
        elif backbone_name == "vgg16":
            self.backbone = VGG16(
                weights='imagenet',
                include_top=False,
                input_shape=(img_height, img_width, 3)
            )

        # Замораживаем веса backbone (как в ViT)
        self.backbone.trainable = False

        # Глобальное усреднение
        self.global_avg_pool = GlobalAveragePooling2D()

        # Классификационная голова (аналогично ViT)
        self.dropout1 = Dropout(0.3)
        self.dense1 = Dense(512, activation='relu')
        self.dropout2 = Dropout(0.2)
        self.dense2 = Dense(256, activation='relu')
        self.classifier = Dense(num_classes, activation='softmax')

    def call(self, inputs, training=None):
        # Получаем признаки от предобученной модели
        x = self.backbone(inputs, training=training)

        # Глобальное усреднение
        x = self.global_avg_pool(x)

        # Пропускаем через классификационную голову
        x = self.dropout1(x, training=training)
        x = self.dense1(x)
        x = self.dropout2(x, training=training)
        x = self.dense2(x)
        outputs = self.classifier(x)

        return outputs

    def get_config(self):
        config = super().get_config()
        config.update({
            "num_classes": self.num_classes,
            "backbone_name": self.backbone_name
        })
        return config


def build_pretrained_cnn_model(num_classes, backbone_name="efficientnet"):
    """Создание модели CNN с использованием предобученного backbone"""
    try:
        model = CNNForImageClassification(
            num_classes=num_classes,
            backbone_name=backbone_name
        )

        # Строим модель, передав пример входных данных
        dummy_input = tf.random.normal((1, img_height, img_width, 3))
        _ = model(dummy_input)

        return model

    except Exception as e:
        print(f"Ошибка при создании модели с backbone {backbone_name}: {e}")
        raise e


# Создание модели
backbone_options = ["efficientnet", "resnet50", "vgg16"]
selected_backbone = "efficientnet"  # Можно изменить на "resnet50" или "vgg16"

cnn_model = build_pretrained_cnn_model(num_classes, backbone_name=selected_backbone)
print(f"Используется предобученная {selected_backbone.upper()} модель")

# Настройка оптимизатора и компиляция (точно как в ViT)
lr_schedule = tf.keras.optimizers.schedules.ExponentialDecay(
    initial_learning_rate=initial_learning_rate,
    decay_steps=1000,
    decay_rate=0.9,
    staircase=True
)

optimizer = Adam(learning_rate=lr_schedule)
cnn_model.compile(
    optimizer=optimizer,
    loss='categorical_crossentropy',
    metrics=['accuracy', tf.keras.metrics.AUC(name="auc")]
)

print("Архитектура модели:")
print(f"Входные данные: {img_height}x{img_width}x3")
print(f"Backbone: {selected_backbone.upper()}")
print(f"Количество классов: {num_classes}")
print(f"Batch size: {batch_size}")

# Показать количество параметров
total_params = cnn_model.count_params()
trainable_params = sum([tf.size(var).numpy() for var in cnn_model.trainable_variables])
frozen_params = total_params - trainable_params

print(f"\nПараметры модели:")
print(f"Всего параметров: {total_params:,}")
print(f"Обучаемых параметров: {trainable_params:,}")
print(f"Замороженных параметров: {frozen_params:,}")


class MetricsCallback(tf.keras.callbacks.Callback):
    """Callback для дополнительных метрик (копия из ViT)"""

    def __init__(self, validation_data, batch_size):
        super(MetricsCallback, self).__init__()
        self.validation_data = validation_data
        self.batch_size = batch_size

    def on_epoch_end(self, epoch, logs=None):
        logs = logs or {}

        # Сброс генератора
        self.validation_data.reset()

        # Предсказания
        y_pred = self.model.predict(self.validation_data, verbose=0)
        y_true = self.validation_data.classes
        y_pred_classes = np.argmax(y_pred, axis=1)

        # Вычисление метрик
        f1 = f1_score(y_true, y_pred_classes, average='weighted')

        try:
            y_true_onehot = tf.keras.utils.to_categorical(y_true, num_classes=y_pred.shape[1])
            roc_auc = roc_auc_score(y_true_onehot, y_pred, multi_class='ovr', average='weighted')
        except Exception as e:
            roc_auc = 0.0

        # Измерение производительности
        val_batch = next(iter(self.validation_data))
        start_time = time.time()
        _ = self.model.predict(val_batch[0], verbose=0)
        elapsed_time = time.time() - start_time
        latency = (elapsed_time / len(val_batch[0])) * 1000
        throughput = len(val_batch[0]) / elapsed_time

        logs['val_f1'] = f1
        logs['val_roc_auc'] = roc_auc

        print(f"\nEpoch {epoch + 1}: val_f1: {f1:.4f}, val_roc_auc: {roc_auc:.4f}")
        print(f"Latency: {latency:.2f} ms, Throughput: {throughput:.2f} images/sec")


# Настройка callbacks (точно как в ViT)
os.makedirs("./models/affectNetPreTraining", exist_ok=True)
checkpoint = ModelCheckpoint(
    f"models/affectNetPreTraining/pretrained_{selected_backbone}_model.h5",
    monitor='val_accuracy',
    save_best_only=True,
    mode='max',
    verbose=1
)
early_stop = EarlyStopping(
    monitor='val_accuracy',
    patience=8,  # Тот же patience как в ViT
    restore_best_weights=True,
    verbose=1
)
tensorboard = TensorBoard(
    log_dir=f"./logs/affectNetPreTraining/pretrained_{selected_backbone}",
    histogram_freq=1
)
metrics_callback = MetricsCallback(
    validation_data=validation_generator,
    batch_size=batch_size
)

callbacks = [checkpoint, early_stop, tensorboard, metrics_callback]

# Обучение модели
print("Начинаем обучение...")
history = cnn_model.fit(
    train_generator,
    steps_per_epoch=train_generator.samples // batch_size,
    epochs=epochs,
    validation_data=validation_generator,
    validation_steps=validation_generator.samples // batch_size,
    callbacks=callbacks,
    verbose=1
)

# Сохранение истории обучения
with open(f"./models/affectNetPreTraining/pretrained_{selected_backbone}_training_history.pkl", "wb") as f:
    pickle.dump(history.history, f)

# Финальная оценка
print("\nФинальная оценка модели...")
validation_generator.reset()
val_loss, val_accuracy, val_auc = cnn_model.evaluate(
    validation_generator,
    steps=validation_generator.samples // batch_size
)

print(f"Validation Accuracy: {val_accuracy * 100:.2f}%")
print(f"Validation AUC: {val_auc:.4f}")

# Получение предсказаний для детального анализа
validation_generator.reset()
y_pred = cnn_model.predict(validation_generator, verbose=1)
y_pred_classes = np.argmax(y_pred, axis=1)
y_true = validation_generator.classes

# Отчет о классификации
print("\nClassification Report:")
print(classification_report(y_true, y_pred_classes, target_names=list(class_indices.keys())))

# Матрица ошибок
plt.figure(figsize=(12, 10))
cm = confusion_matrix(y_true, y_pred_classes)
sns.heatmap(
    cm,
    annot=True,
    fmt='d',
    xticklabels=list(class_indices.keys()),
    yticklabels=list(class_indices.keys()),
    cmap='Blues'
)
plt.title(f'Confusion Matrix - Pretrained {selected_backbone.upper()}')
plt.xlabel('Predicted Classes')
plt.ylabel('True Classes')
plt.tight_layout()
plt.savefig(f'pretrained_{selected_backbone}_confusion_matrix.png', dpi=300, bbox_inches='tight')
plt.show()

# Графики обучения
fig, axes = plt.subplots(2, 2, figsize=(15, 10))

# Accuracy
axes[0, 0].plot(history.history['accuracy'], label='Training Accuracy')
axes[0, 0].plot(history.history['val_accuracy'], label='Validation Accuracy')
axes[0, 0].set_title('Model Accuracy')
axes[0, 0].set_xlabel('Epoch')
axes[0, 0].set_ylabel('Accuracy')
axes[0, 0].legend()

# Loss
axes[0, 1].plot(history.history['loss'], label='Training Loss')
axes[0, 1].plot(history.history['val_loss'], label='Validation Loss')
axes[0, 1].set_title('Model Loss')
axes[0, 1].set_xlabel('Epoch')
axes[0, 1].set_ylabel('Loss')
axes[0, 1].legend()

# AUC
axes[1, 0].plot(history.history['auc'], label='Training AUC')
axes[1, 0].plot(history.history['val_auc'], label='Validation AUC')
axes[1, 0].set_title('Model AUC')
axes[1, 0].set_xlabel('Epoch')
axes[1, 0].set_ylabel('AUC')
axes[1, 0].legend()

# F1 Score (если доступно)
if 'val_f1' in history.history:
    axes[1, 1].plot(history.history['val_f1'], label='Validation F1')
    axes[1, 1].set_title('F1 Score')
    axes[1, 1].set_xlabel('Epoch')
    axes[1, 1].set_ylabel('F1 Score')
    axes[1, 1].legend()

plt.tight_layout()
plt.savefig(f'pretrained_{selected_backbone}_training_history.png', dpi=300, bbox_inches='tight')
plt.show()

# Сохранение финальной модели
cnn_model.save(f"models/affectNetPreTraining/final_pretrained_{selected_backbone}_model.h5")
print("Модель сохранена!")

# Опциональная разморозка и дообучение (аналогично ViT)
print("\n" + "=" * 50)
print("ОПЦИОНАЛЬНАЯ РАЗМОРОЗКА МОДЕЛИ ДЛЯ FINE-TUNING")
print("=" * 50)

fine_tune = input("Хотите провести fine-tuning с разморозкой слоев? (y/n): ").lower() == 'y'

if fine_tune:
    # Размораживаем backbone для fine-tuning
    cnn_model.backbone.trainable = True

    # Замораживаем только первые слои backbone
    # Для EfficientNet/ResNet размораживаем последние блоки
    if selected_backbone == "efficientnet":
        # Замораживаем первые 100 слоев, размораживаем остальные
        for layer in cnn_model.backbone.layers[:-30]:
            layer.trainable = False
    elif selected_backbone == "resnet50":
        # Замораживаем первые слои, размораживаем последний блок
        for layer in cnn_model.backbone.layers[:-20]:
            layer.trainable = False
    elif selected_backbone == "vgg16":
        # Замораживаем первые слои, размораживаем последние
        for layer in cnn_model.backbone.layers[:-4]:
            layer.trainable = False

    # Компилируем с меньшим learning rate
    cnn_model.compile(
        optimizer=Adam(learning_rate=initial_learning_rate / 10),
        loss='categorical_crossentropy',
        metrics=['accuracy', tf.keras.metrics.AUC(name="auc")]
    )

    print("Начинаем fine-tuning...")

    # Обучаем еще несколько эпох
    fine_tune_epochs = 10
    total_epochs = len(history.history['loss']) + fine_tune_epochs

    history_fine = cnn_model.fit(
        train_generator,
        steps_per_epoch=train_generator.samples // batch_size,
        epochs=total_epochs,
        initial_epoch=len(history.history['loss']),
        validation_data=validation_generator,
        validation_steps=validation_generator.samples // batch_size,
        callbacks=[checkpoint, early_stop, metrics_callback],
        verbose=1
    )

    # Сохраняем fine-tuned модель
    cnn_model.save(f"models/affectNetPreTraining/fine_tuned_{selected_backbone}_model.h5")

    # Финальная оценка после fine-tuning
    validation_generator.reset()
    val_loss, val_accuracy, val_auc = cnn_model.evaluate(
        validation_generator,
        steps=validation_generator.samples // batch_size
    )

    print(f"Final Fine-tuned Validation Accuracy: {val_accuracy * 100:.2f}%")
    print(f"Final Fine-tuned Validation AUC: {val_auc:.4f}")

print("\nОбучение завершено!")

# Вывод финальной сводки для сравнения
print("\n" + "=" * 60)
print("СВОДКА ДЛЯ СРАВНЕНИЯ С ViT")
print("=" * 60)
print(f"Backbone: {selected_backbone.upper()}")
print(f"Размер изображения: {img_height}x{img_width}")
print(f"Batch size: {batch_size}")
print(f"Learning rate: {initial_learning_rate}")
print(f"Количество эпох: {epochs}")
print(f"Всего параметров: {total_params:,}")
print(f"Обучаемых параметров: {trainable_params:,}")
print(f"Validation Accuracy: {val_accuracy * 100:.2f}%")
print(f"Validation AUC: {val_auc:.4f}")
print("=" * 60)