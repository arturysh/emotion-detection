import os
import pickle
import time
import random
import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow.keras import layers, models
from tensorflow.keras.preprocessing.image import load_img, img_to_array
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping, TensorBoard
from tensorflow.keras.regularizers import l2
from tensorflow.keras.utils import to_categorical, Sequence
from sklearn.metrics import f1_score, roc_auc_score, classification_report, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns
from PIL import Image
import cv2

seed_value = 42
tf.random.set_seed(seed_value)
np.random.seed(seed_value)
random.seed(seed_value)

# Parameters
dataset_dir = "./dataset/affectNet/"
train_csv = os.path.join(dataset_dir, "training.csv")
val_csv = os.path.join(dataset_dir, "validation.csv")
img_height, img_width = 96, 96
input_shape = (img_height, img_width, 1)
batch_size = 32
epochs = 50

# Emotion labels (0-6)
emotion_labels = ['Neutral', 'Happy', 'Sad', 'Surprise', 'Fear', 'Disgust', 'Anger']
num_classes = len(emotion_labels)


class AffectNetDataGenerator(Sequence):
    def __init__(self, csv_file, dataset_dir, batch_size=32, img_size=(96, 96),
                 augment=False, shuffle=True):
        self.dataset_dir = dataset_dir
        self.batch_size = batch_size
        self.img_size = img_size
        self.augment = augment
        self.shuffle = shuffle

        # Load CSV and filter by expression (0-6)
        self.df = pd.read_csv(csv_file)
        self.df = self.df[self.df['expression'].isin(range(7))]  # 0-6 inclusive
        self.df = self.df.reset_index(drop=True)

        self.indices = np.arange(len(self.df))
        if self.shuffle:
            np.random.shuffle(self.indices)

    def __len__(self):
        return len(self.df) // self.batch_size

    def __getitem__(self, idx):
        batch_indices = self.indices[idx * self.batch_size:(idx + 1) * self.batch_size]
        batch_x, batch_y = self._generate_batch(batch_indices)
        return batch_x, batch_y

    def _generate_batch(self, batch_indices):
        batch_x = np.zeros((self.batch_size, *self.img_size, 1), dtype=np.float32)
        batch_y = np.zeros((self.batch_size, num_classes), dtype=np.float32)

        for i, idx in enumerate(batch_indices):
            row = self.df.iloc[idx]

            # Load and preprocess image
            img_path = os.path.join(self.dataset_dir, row['subDirectory_filePath'])
            img = self._load_and_preprocess_image(img_path, row)

            # Augmentation for training data
            if self.augment:
                img = self._augment_image(img)

            batch_x[i] = img
            batch_y[i] = to_categorical(row['expression'], num_classes)

        return batch_x, batch_y

    def _load_and_preprocess_image(self, img_path, row):
        try:
            # Load image
            img = cv2.imread(img_path)
            if img is None:
                # If cv2 cannot load, try PIL
                img = Image.open(img_path)
                img = np.array(img)

            # Convert to RGB if necessary
            if len(img.shape) == 3 and img.shape[2] == 3:
                img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

            # Extract face region by coordinates
            face_x = int(row['face_x'])
            face_y = int(row['face_y'])
            face_w = int(row['face_width'])
            face_h = int(row['face_height'])

            # Crop face with boundary check
            h, w = img.shape[:2]
            x1 = max(0, face_x)
            y1 = max(0, face_y)
            x2 = min(w, face_x + face_w)
            y2 = min(h, face_y + face_h)

            face_img = img[y1:y2, x1:x2]

            # If face region is too small, use the entire image
            if face_img.shape[0] < 10 or face_img.shape[1] < 10:
                face_img = img

            # Convert to grayscale
            if len(face_img.shape) == 3:
                face_img = cv2.cvtColor(face_img, cv2.COLOR_RGB2GRAY)

            # Resize
            face_img = cv2.resize(face_img, self.img_size)

            # Normalization
            face_img = face_img.astype(np.float32) / 255.0

            # Add channel
            face_img = np.expand_dims(face_img, axis=-1)

            return face_img

        except Exception as e:
            print(f"Error loading {img_path}: {e}")
            # Return empty image in case of error
            empty_img = np.zeros((*self.img_size, 1), dtype=np.float32)
            return empty_img

    def _augment_image(self, img):
        # Simple augmentation
        if random.random() > 0.5:
            # Horizontal flip
            img = np.fliplr(img)

        if random.random() > 0.5:
            # Small rotation
            angle = random.uniform(-15, 15)
            center = (self.img_size[1] // 2, self.img_size[0] // 2)
            M = cv2.getRotationMatrix2D(center, angle, 1.0)
            img = cv2.warpAffine(img.squeeze(), M, self.img_size)
            img = np.expand_dims(img, axis=-1)

        if random.random() > 0.5:
            # Change brightness
            brightness = random.uniform(0.9, 1.1)
            img = np.clip(img * brightness, 0.0, 1.0)

        return img

    def on_epoch_end(self):
        if self.shuffle:
            np.random.shuffle(self.indices)


# Create data generators
print("Creating data generators...")
train_generator = AffectNetDataGenerator(
    csv_file=train_csv,
    dataset_dir=dataset_dir,
    batch_size=batch_size,
    img_size=(img_height, img_width),
    augment=True,
    shuffle=True
)

validation_generator = AffectNetDataGenerator(
    csv_file=val_csv,
    dataset_dir=dataset_dir,
    batch_size=batch_size,
    img_size=(img_height, img_width),
    augment=False,
    shuffle=False
)

print(f"Number of training examples: {len(train_generator.df)}")
print(f"Number of validation examples: {len(validation_generator.df)}")
print(f"Number of classes: {num_classes}")
print(f"Emotion classes: {emotion_labels}")


# Rest of the code remains unchanged
class Patches(layers.Layer):
    def __init__(self, patch_size, **kwargs):
        super(Patches, self).__init__(**kwargs)
        self.patch_size = patch_size

    def call(self, images):
        batch_size = tf.shape(images)[0]
        patches = tf.image.extract_patches(
            images=images,
            sizes=[1, self.patch_size, self.patch_size, 1],
            strides=[1, self.patch_size, self.patch_size, 1],
            rates=[1, 1, 1, 1],
            padding='VALID'
        )
        patch_dims = patches.shape[-1]
        patches = tf.reshape(patches, [batch_size, -1, patch_dims])
        return patches

    def get_config(self):
        config = super().get_config()
        config.update({
            "patch_size": self.patch_size,
        })
        return config


class PatchEncoder(layers.Layer):
    def __init__(self, num_patches, projection_dim, **kwargs):
        super(PatchEncoder, self).__init__(**kwargs)
        self.num_patches = num_patches
        self.projection = layers.Dense(units=projection_dim)
        self.position_embedding = layers.Embedding(input_dim=num_patches, output_dim=projection_dim)

    def call(self, patches):
        positions = tf.range(start=0, limit=self.num_patches, delta=1)
        encoded = self.projection(patches) + self.position_embedding(positions)
        return encoded

    def get_config(self):
        config = super().get_config()
        config.update({
            "num_patches": self.num_patches,
            "projection_dim": self.projection.units,
        })
        return config


class MetricsCallback(tf.keras.callbacks.Callback):
    def __init__(self, validation_data, batch_size):
        super(MetricsCallback, self).__init__()
        self.validation_data = validation_data
        self.batch_size = batch_size

    def on_epoch_end(self, epoch, logs=None):
        logs = logs or {}

        # Collect predictions and true labels
        y_pred_list = []
        y_true_list = []

        for i in range(len(self.validation_data)):
            batch_x, batch_y = self.validation_data[i]
            y_pred_batch = self.model.predict(batch_x, verbose=0)
            y_pred_list.append(y_pred_batch)
            y_true_list.append(batch_y)

        y_pred = np.vstack(y_pred_list)
        y_true = np.vstack(y_true_list)

        y_pred_classes = np.argmax(y_pred, axis=1)
        y_true_classes = np.argmax(y_true, axis=1)

        f1 = f1_score(y_true_classes, y_pred_classes, average='weighted')

        try:
            roc_auc = roc_auc_score(y_true, y_pred, multi_class='ovr', average='weighted')
        except Exception as e:
            roc_auc = 0.0

        # Measure performance
        start_time = time.time()
        sample_batch = next(iter(self.validation_data))
        _ = self.model.predict(sample_batch[0], verbose=0)
        elapsed_time = time.time() - start_time
        latency = (elapsed_time / self.batch_size) * 1000
        throughput = self.batch_size / elapsed_time

        logs['val_f1'] = f1
        logs['val_roc_auc'] = roc_auc
        print(f"\nEpoch {epoch + 1}: val_f1: {f1:.4f}, val_roc_auc: {roc_auc:.4f}")
        print(f"Average latency per image: {latency:.2f} ms, Throughput: {throughput:.2f} images/sec")


def build_vit_model(input_shape, num_classes, patch_size=16, projection_dim=64,
                    transformer_layers=4, num_heads=4, transformer_units=[256, 256],
                    mlp_head_units=[128], dropout_rate=0.1, l2_lambda=1e-4):
    inputs = layers.Input(shape=input_shape)
    patches = Patches(patch_size)(inputs)
    num_patches = (img_height // patch_size) * (img_width // patch_size)
    encoded_patches = PatchEncoder(num_patches, projection_dim)(patches)
    for _ in range(transformer_layers):
        x1 = layers.LayerNormalization(epsilon=1e-6)(encoded_patches)
        attention_output = layers.MultiHeadAttention(num_heads=num_heads,
                                                     key_dim=projection_dim,
                                                     dropout=dropout_rate)(x1, x1)
        x2 = layers.Add()([attention_output, encoded_patches])
        x3 = layers.LayerNormalization(epsilon=1e-6)(x2)
        mlp_output = layers.Dense(transformer_units[0], activation='relu',
                                  kernel_regularizer=l2(l2_lambda))(x3)
        mlp_output = layers.Dropout(dropout_rate)(mlp_output)
        mlp_output = layers.Dense(transformer_units[1], activation='relu',
                                  kernel_regularizer=l2(l2_lambda))(mlp_output)
        mlp_output = layers.Dropout(dropout_rate)(mlp_output)
        encoded_patches = layers.Add()([mlp_output, x2])
    representation = layers.LayerNormalization(epsilon=1e-6)(encoded_patches)
    representation = layers.GlobalAveragePooling1D()(representation)
    for units in mlp_head_units:
        representation = layers.Dense(units, activation='relu', kernel_regularizer=l2(l2_lambda))(representation)
        representation = layers.Dropout(dropout_rate)(representation)
    outputs = layers.Dense(num_classes, activation='softmax')(representation)
    model = models.Model(inputs=inputs, outputs=outputs)
    return model


def train_model_vit(model, train_generator, validation_generator, epochs, batch_size):
    lr_schedule = tf.keras.optimizers.schedules.ExponentialDecay(
        initial_learning_rate=0.001,
        decay_steps=10000,
        decay_rate=0.96,
        staircase=True
    )
    optimizer = Adam(learning_rate=lr_schedule)
    loss_fn = tf.keras.losses.CategoricalCrossentropy(label_smoothing=0.1)
    model.compile(optimizer=optimizer, loss=loss_fn, metrics=['accuracy', tf.keras.metrics.AUC(name="auc")])
    model.summary()

    os.makedirs("./models/affectNetPlus/vit", exist_ok=True)
    checkpoint = ModelCheckpoint("models/affectNetPlus/vit/improved_vit_model.h5", monitor='val_accuracy', verbose=1,
                                 save_best_only=True, mode='max')
    early_stop = EarlyStopping(monitor='val_accuracy', patience=10, verbose=1, mode='max')
    tensorboard = TensorBoard(log_dir="./logs/affectNetPlus/vit", histogram_freq=1)
    metrics_callback = MetricsCallback(validation_data=validation_generator, batch_size=batch_size)
    callbacks_list = [checkpoint, early_stop, tensorboard, metrics_callback]

    history = model.fit(
        train_generator,
        steps_per_epoch=len(train_generator),
        epochs=epochs,
        validation_data=validation_generator,
        validation_steps=len(validation_generator),
        callbacks=callbacks_list
    )

    with open("./models/affectNetPlus/vit/vit_training_history.pkl", "wb") as f:
        pickle.dump(history.history, f)

    loss, accuracy, auc = model.evaluate(validation_generator, steps=len(validation_generator))
    print("Improved ViT - Validation Accuracy: {:.2f}%".format(accuracy * 100))
    print("Improved ViT - Validation AUC: {:.4f}".format(auc))
    return history


# Model parameters
patch_size = 16
projection_dim = 64
transformer_layers = 4
num_heads = 4
transformer_units = [256, 256]
mlp_head_units = [128]
dropout_rate = 0.1

# Build and train model
print("Creating ViT model...")
vit_model = build_vit_model(
    input_shape=input_shape,
    num_classes=num_classes,
    patch_size=patch_size,
    projection_dim=projection_dim,
    transformer_layers=transformer_layers,
    num_heads=num_heads,
    transformer_units=transformer_units,
    mlp_head_units=mlp_head_units,
    dropout_rate=dropout_rate,
    l2_lambda=1e-4
)

print("Starting training...")
history = train_model_vit(vit_model, train_generator, validation_generator, epochs, batch_size)

# Model evaluation
print("Evaluating model on validation data...")
y_pred_list = []
y_true_list = []

for i in range(len(validation_generator)):
    batch_x, batch_y = validation_generator[i]
    y_pred_batch = vit_model.predict(batch_x, verbose=0)
    y_pred_list.append(y_pred_batch)
    y_true_list.append(batch_y)

y_pred = np.vstack(y_pred_list)
y_true = np.vstack(y_true_list)

y_pred_classes = np.argmax(y_pred, axis=1)
y_true_classes = np.argmax(y_true, axis=1)

print("\nClassification Report:")
print(classification_report(y_true_classes, y_pred_classes, target_names=emotion_labels))

# Confusion matrix
plt.figure(figsize=(10, 8))
cm = confusion_matrix(y_true_classes, y_pred_classes)
sns.heatmap(cm, annot=True, fmt='d', xticklabels=emotion_labels, yticklabels=emotion_labels)
plt.title('Confusion Matrix - affectNetPlus ViT')
plt.xlabel('Predicted Classes')
plt.ylabel('True Classes')
plt.tight_layout()
plt.savefig('affectnet_vit_confusion_matrix.png')
plt.show()

# Save final model
vit_model.save("models/affectNetPlus/vit/improved_vit_model_final.h5")
print("Model saved to models/affectNetPlus/vit/improved_vit_model_final.h5")