import os
import pickle
import time
import random
import numpy as np
import pandas as pd
import cv2
import tensorflow as tf
from tensorflow.keras import layers, models, Input, regularizers
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping, ReduceLROnPlateau, TensorBoard
from sklearn.metrics import f1_score, roc_auc_score, classification_report
from sklearn.utils.class_weight import compute_class_weight

# Установка seed для воспроизводимости
seed_value = 42
tf.random.set_seed(seed_value)
np.random.seed(seed_value)
random.seed(seed_value)

# Пути к CSV файлам (как в обычной модели)
train_csv_path = "./dataset/affectNet/training.csv"
val_csv_path = "./dataset/affectNet/validation.csv"
base_image_path = "./dataset/affectNet/"

# УНИФИЦИРОВАННЫЕ параметры модели (как в обычной модели)
img_height, img_width = 48, 48
channels = 1
batch_size = 64  # Как в обычной модели
epochs = 30  # Как в обычной модели

# Маппинг эмоций (как в обычной модели)
emotion_mapping = {
    0: 0, 1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6
}
emotion_names = ['Neutral', 'Happy', 'Sad', 'Surprise', 'Fear', 'Disgust', 'Anger']


def load_and_filter_data(csv_path):
    """Загружает и фильтрует данные из CSV с проверкой файлов (как в обычной модели)"""
    df = pd.read_csv(csv_path)
    df_filtered = df[df['expression'].isin(list(emotion_mapping.keys()))].copy()
    df_filtered['expression'] = df_filtered['expression'].map(emotion_mapping)

    # Проверяем существование файлов и удаляем несуществующие
    valid_indices = []
    for idx, row in df_filtered.iterrows():
        image_path = os.path.join(base_image_path, row['subDirectory_filePath'])
        if os.path.exists(image_path):
            valid_indices.append(idx)
        else:
            print(f"Файл не найден: {image_path}")

    df_filtered = df_filtered.loc[valid_indices].reset_index(drop=True)

    print(f"Исходное количество образцов: {len(df)}")
    print(f"После фильтрации: {len(df_filtered)}")
    print(f"Распределение классов:")
    for emotion_id, emotion_name in enumerate(emotion_names):
        count = len(df_filtered[df_filtered['expression'] == emotion_id])
        print(f"  {emotion_id} ({emotion_name}): {count}")

    return df_filtered


def preprocess_image(image_path, face_coords=None, target_size=(48, 48)):
    """Улучшенная предобработка изображения (как в обычной модели)"""
    try:
        image = cv2.imread(image_path)
        if image is None:
            return None

        # Crop по координатам лица
        if face_coords is not None and not any(pd.isna(coord) for coord in face_coords):
            x, y, w, h = map(int, face_coords)
            h_img, w_img = image.shape[:2]
            x = max(0, min(x, w_img))
            y = max(0, min(y, h_img))
            w = max(1, min(w, w_img - x))
            h = max(1, min(h, h_img - y))
            image = image[y:y + h, x:x + w]

        # Конвертируем в grayscale
        if len(image.shape) == 3:
            image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

        # Изменяем размер
        image = cv2.resize(image, target_size)

        # Улучшенная нормализация с выравниванием гистограммы
        image = cv2.equalizeHist(image)
        image = image.astype(np.float32) / 255.0

        # Стандартизация (важно для стабильного обучения)
        image = (image - 0.5) / 0.5

        image = np.expand_dims(image, axis=-1)
        return image
    except Exception as e:
        print(f"Ошибка при обработке изображения {image_path}: {e}")
        return None


class CSVDataGenerator(tf.keras.utils.Sequence):
    """Улучшенный генератор данных (как в обычной модели)"""

    def __init__(self, dataframe, base_path, batch_size=32, target_size=(48, 48),
                 use_face_crop=True, augmentation=None, shuffle=True):
        self.dataframe = dataframe.reset_index(drop=True)
        self.base_path = base_path
        self.batch_size = batch_size
        self.target_size = target_size
        self.use_face_crop = use_face_crop
        self.augmentation = augmentation
        self.shuffle = shuffle
        self.num_classes = len(emotion_names)
        self.classes = self.dataframe['expression'].values
        self.class_indices = {name: idx for idx, name in enumerate(emotion_names)}
        self.on_epoch_end()

    def __len__(self):
        return int(np.ceil(len(self.dataframe) / self.batch_size))

    def __getitem__(self, index):
        start_idx = index * self.batch_size
        end_idx = min((index + 1) * self.batch_size, len(self.dataframe))
        batch_indices = self.indices[start_idx:end_idx]
        return self.__data_generation(batch_indices)

    def on_epoch_end(self):
        self.indices = np.arange(len(self.dataframe))
        if self.shuffle:
            np.random.shuffle(self.indices)

    def __data_generation(self, batch_indices):
        X = np.empty((len(batch_indices), *self.target_size, 1))
        y = np.empty((len(batch_indices), self.num_classes))

        for i, idx in enumerate(batch_indices):
            row = self.dataframe.iloc[idx]
            image_path = os.path.join(self.base_path, row['subDirectory_filePath'])

            face_coords = None
            if self.use_face_crop:
                face_coords = [row['face_x'], row['face_y'], row['face_width'], row['face_height']]

            image = preprocess_image(image_path, face_coords, self.target_size)

            if image is None:
                # Создаем случайный шум вместо нулей
                image = np.random.normal(0, 0.1, (*self.target_size, 1))

            X[i] = image
            label = row['expression']
            y[i] = tf.keras.utils.to_categorical(label, self.num_classes)

        return X, y


# УНИФИЦИРОВАННАЯ архитектура Plus модели с SE-блоками и Residual connections
def se_block(input_tensor, ratio=16, l2_lambda=1e-5):
    """Squeeze-and-Excitation блок с уменьшенной регуляризацией"""
    filters = input_tensor.shape[-1]
    se = layers.GlobalAveragePooling2D()(input_tensor)
    se = layers.Reshape((1, 1, filters))(se)
    se = layers.Dense(filters // ratio, activation='relu', kernel_regularizer=regularizers.l2(l2_lambda))(se)
    se = layers.Dense(filters, activation='sigmoid', kernel_regularizer=regularizers.l2(l2_lambda))(se)
    x = layers.multiply([input_tensor, se])
    return x


def residual_se_block(x, filters, kernel_size, dropout_rate, l2_lambda):
    """Residual блок с SE-блоком (упрощенный для соответствия обычной модели)"""
    l2_reg = regularizers.l2(l2_lambda)
    shortcut = x

    # Первая свертка
    x = layers.Conv2D(filters, kernel_size, activation="relu", padding="same", kernel_regularizer=l2_reg)(x)
    x = layers.BatchNormalization()(x)

    # Вторая свертка
    x = layers.Conv2D(filters, kernel_size, activation="relu", padding="same", kernel_regularizer=l2_reg)(x)
    x = layers.BatchNormalization()(x)

    # Приведение размерности shortcut, если необходимо
    if shortcut.shape[-1] != filters:
        shortcut = layers.Conv2D(filters, (1, 1), padding="same", kernel_regularizer=l2_reg)(shortcut)
        shortcut = layers.BatchNormalization()(shortcut)

    # Residual connection
    x = layers.add([x, shortcut])

    # SE-блок
    x = se_block(x, l2_lambda=l2_lambda)

    # Pooling и Dropout
    x = layers.MaxPooling2D(pool_size=(2, 2))(x)
    x = layers.Dropout(dropout_rate)(x)

    return x


def build_plus_cnn_model(input_shape, num_classes):
    """
    Plus архитектура с SE-блоками и Residual connections,
    адаптированная под условия обычной модели
    """
    inputs = Input(shape=input_shape)

    # Уменьшенная регуляризация для соответствия обычной модели
    l2_lambda = 1e-5

    # Блок 1: 32 фильтра (соответствует обычной модели)
    x = residual_se_block(inputs, filters=32, kernel_size=3, dropout_rate=0.1, l2_lambda=l2_lambda)

    # Блок 2: 64 фильтра (соответствует обычной модели)
    x = residual_se_block(x, filters=64, kernel_size=3, dropout_rate=0.15, l2_lambda=l2_lambda)

    # Блок 3: 128 фильтров (соответствует обычной модели)
    x = residual_se_block(x, filters=128, kernel_size=3, dropout_rate=0.2, l2_lambda=l2_lambda)

    # Блок 4: 256 фильтров (финальный блок как в обычной модели)
    x = layers.Conv2D(256, (3, 3), activation='relu', padding='same', kernel_regularizer=regularizers.l2(l2_lambda))(x)
    x = layers.BatchNormalization()(x)
    x = se_block(x, l2_lambda=l2_lambda)
    x = layers.GlobalAveragePooling2D()(x)

    # Классификатор (как в обычной модели)
    x = layers.Dense(128, activation='relu', kernel_regularizer=regularizers.l2(l2_lambda))(x)
    x = layers.BatchNormalization()(x)
    x = layers.Dropout(0.3)(x)

    outputs = layers.Dense(num_classes, activation='softmax')(x)

    model = models.Model(inputs, outputs)
    return model


class MetricsCallback(tf.keras.callbacks.Callback):
    """Унифицированный callback для метрик (как в обычной модели)"""

    def __init__(self, validation_data, batch_size):
        super(MetricsCallback, self).__init__()
        self.validation_data = validation_data
        self.batch_size = batch_size

    def on_epoch_end(self, epoch, logs=None):
        logs = logs or {}

        # Получаем предсказания и истинные метки
        y_pred = self.model.predict(self.validation_data, verbose=0)
        y_true = self.validation_data.classes
        y_pred_classes = np.argmax(y_pred, axis=1)

        # Вычисляем метрики
        f1 = f1_score(y_true, y_pred_classes, average='weighted')

        try:
            y_true_onehot = tf.keras.utils.to_categorical(y_true, num_classes=y_pred.shape[1])
            roc_auc = roc_auc_score(y_true_onehot, y_pred, multi_class='ovr', average='weighted')
        except Exception:
            roc_auc = 0.0

        logs['val_f1'] = f1
        logs['val_roc_auc'] = roc_auc

        print(f"\nEpoch {epoch + 1}: val_f1: {f1:.4f}, val_roc_auc: {roc_auc:.4f}")

        # Детальный отчет только каждые 5 эпох
        if (epoch + 1) % 5 == 0:
            report = classification_report(y_true, y_pred_classes,
                                           target_names=emotion_names, digits=4)
            print("Class-wise Performance:\n", report)


def train_model_unified(model, train_generator, validation_generator, epochs, batch_size):
    """Унифицированная функция обучения (как в обычной модели)"""

    # Консервативные параметры как в обычной модели
    optimizer = Adam(learning_rate=0.0005)

    model.compile(
        optimizer=optimizer,
        loss='categorical_crossentropy',  # Без label smoothing для честного сравнения
        metrics=['accuracy', tf.keras.metrics.AUC(name="auc")]
    )

    model.summary()
    trainable_params = np.sum([tf.keras.backend.count_params(w) for w in model.trainable_weights])
    print("Total trainable parameters:", trainable_params)

    os.makedirs("./models/affectNetPlus/cnn", exist_ok=True)

    # Те же callbacks что и в обычной модели
    checkpoint = ModelCheckpoint(
        "models/affectNetPlus/cnn/plus_cnn_model_unified.h5",
        monitor="val_accuracy",
        verbose=1,
        save_best_only=True,
        mode="max"
    )

    early_stop = EarlyStopping(
        monitor="val_loss",
        patience=8,
        verbose=1,
        mode="min",
        restore_best_weights=True
    )

    reduce_lr = ReduceLROnPlateau(
        monitor="val_loss",
        factor=0.7,
        patience=4,
        verbose=1,
        min_lr=1e-7
    )

    metrics_callback = MetricsCallback(validation_data=validation_generator, batch_size=batch_size)

    callbacks_list = [checkpoint, early_stop, reduce_lr, metrics_callback]

    # Обучение БЕЗ class_weight для честного сравнения
    history = model.fit(
        train_generator,
        epochs=epochs,
        validation_data=validation_generator,
        callbacks=callbacks_list,
        verbose=1
    )

    return history


# Основной код
if __name__ == "__main__":
    print("Загружаем и проверяем данные...")
    train_df = load_and_filter_data(train_csv_path)
    val_df = load_and_filter_data(val_csv_path)

    # Та же упрощенная аугментация что и в обычной модели
    train_datagen = ImageDataGenerator(
        rotation_range=15,
        zoom_range=0.1,
        width_shift_range=0.05,
        height_shift_range=0.05,
        horizontal_flip=True,
        fill_mode="nearest"
    )

    # Создаем генераторы (как в обычной модели)
    train_generator = CSVDataGenerator(
        train_df, base_image_path, batch_size=batch_size,
        target_size=(img_height, img_width), use_face_crop=True,
        augmentation=None,  # Отключаем аугментацию для честного сравнения
        shuffle=True
    )

    validation_generator = CSVDataGenerator(
        val_df, base_image_path, batch_size=batch_size,
        target_size=(img_height, img_width), use_face_crop=True,
        augmentation=None, shuffle=False
    )

    num_classes = len(emotion_names)
    print(f"Количество классов: {num_classes}")

    # Создаем унифицированную Plus модель
    input_shape = (img_height, img_width, channels)
    model = build_plus_cnn_model(input_shape, num_classes)

    print("Начинаем обучение Plus модели (унифицированная версия)...")
    history = train_model_unified(model, train_generator, validation_generator, epochs, batch_size)

    print("Обучение завершено!")