import os
import pickle
import random
import time
import numpy as np
import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Conv2D, MaxPooling2D, Dropout, BatchNormalization, Reshape, Dense, Bidirectional, LSTM
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping, TensorBoard
from tensorflow.keras.regularizers import l2
from sklearn.metrics import classification_report, confusion_matrix, f1_score, roc_auc_score
import matplotlib.pyplot as plt
import seaborn as sns

seed_value = 42
tf.random.set_seed(seed_value)
np.random.seed(seed_value)
random.seed(seed_value)

train_dir = "./dataset/affectNet/train"
val_dir = "./dataset/affectNet/test"
img_height, img_width = 48, 48
batch_size = 32
epochs = 50
initial_learning_rate = 0.0001

train_datagen = ImageDataGenerator(
    rescale=1.0/255,
    rotation_range=25,
    zoom_range=0.25,
    shear_range=0.1,
    width_shift_range=0.1,
    height_shift_range=0.1,
    horizontal_flip=True,
    brightness_range=[0.9, 1.1],
    fill_mode='nearest'
)
val_datagen = ImageDataGenerator(rescale=1.0/255)

train_generator = train_datagen.flow_from_directory(
    train_dir,
    target_size=(img_height, img_width),
    color_mode="grayscale",
    batch_size=batch_size,
    class_mode="categorical",
    shuffle=True,
    seed=seed_value
)
validation_generator = val_datagen.flow_from_directory(
    val_dir,
    target_size=(img_height, img_width),
    color_mode="grayscale",
    batch_size=batch_size,
    class_mode="categorical",
    shuffle=False,
    seed=seed_value
)

class_indices = train_generator.class_indices
num_classes = len(class_indices)
print("Classes:", class_indices)

rnn_hyperparams = {
    'conv_blocks': [
        {'filters': 32, 'kernel_size': (3, 3), 'dropout': 0.2},
        {'filters': 64, 'kernel_size': (3, 3), 'dropout': 0.3}
    ],
    'rnn_layers': [
        {'units': 128, 'bidirectional': True, 'dropout': 0.3, 'return_sequences': True},
        {'units': 128, 'bidirectional': True, 'dropout': 0.5, 'return_sequences': False}
    ],
    'dense_units': 256,
    'dense_dropout': 0.4,
    'l2_lambda': 1e-4
}

def build_rnn_model(input_shape, num_classes, hyperparams):
    inputs = Input(shape=input_shape)
    x = inputs
    for block in hyperparams['conv_blocks']:
        x = Conv2D(block['filters'], block['kernel_size'], activation='relu', padding='same', kernel_regularizers=l2(hyperparams['l2_lambda']))(x)
        x = BatchNormalization()(x)
        x = MaxPooling2D((2, 2))(x)
        x = Dropout(block['dropout'])(x)
    # После двух блоков: размерность (12, 12, filters) - последний filters=64
    x = Reshape((12, 12 * hyperparams['conv_blocks'][-1]['filters']))(x)
    for layer_params in hyperparams['rnn_layers']:
        if layer_params['bidirectional']:
            x = Bidirectional(LSTM(layer_params['units'], return_sequences=layer_params['return_sequences']))(x)
        else:
            x = LSTM(layer_params['units'], return_sequences=layer_params['return_sequences'])(x)
        x = Dropout(layer_params['dropout'])(x)
    x = Dense(hyperparams['dense_units'], activation='relu', kernel_regularizer=l2(hyperparams['l2_lambda']))(x)
    x = BatchNormalization()(x)
    x = Dropout(hyperparams['dense_dropout'])(x)
    outputs = Dense(num_classes, activation='softmax')(x)
    model = Model(inputs, outputs)
    return model

class MetricsCallback(tf.keras.callbacks.Callback):
    def __init__(self, validation_data, batch_size):
        super(MetricsCallback, self).__init__()
        self.validation_data = validation_data
        self.batch_size = batch_size
    def on_epoch_end(self, epoch, logs=None):
        logs = logs or {}
        y_pred = self.model.predict(self.validation_data, verbose=0)
        y_true = self.validation_data.classes
        y_pred_classes = np.argmax(y_pred, axis=1)
        f1 = f1_score(y_true, y_pred_classes, average='weighted')
        try:
            y_true_onehot = tf.keras.utils.to_categorical(y_true, num_classes=y_pred.shape[1])
            roc_auc = roc_auc_score(y_true_onehot, y_pred, multi_class='ovr', average='weighted')
        except Exception as e:
            roc_auc = 0.0
        val_batch = next(iter(self.validation_data))
        start_time = time.time()
        _ = self.model.predict(val_batch[0], verbose=0)
        elapsed_time = time.time() - start_time
        latency = (elapsed_time / self.batch_size) * 1000
        throughput = self.batch_size / elapsed_time
        logs['val_f1'] = f1
        logs['val_roc_auc'] = roc_auc
        print(f"\nEpoch {epoch+1}: val_f1: {f1:.4f}, val_roc_auc: {roc_auc:.4f}")
        print(f"Latency: {latency:.2f} ms, Throughput: {throughput:.2f} images/sec")

input_shape = (img_height, img_width, 1)
rnn_model = build_rnn_model(input_shape, num_classes, rnn_hyperparams)

lr_schedule = tf.keras.optimizers.schedules.ExponentialDecay(
    initial_learning_rate=initial_learning_rate,
    decay_steps=10000,
    decay_rate=0.96,
    staircase=True
)
optimizer = Adam(learning_rate=lr_schedule)
loss_fn = tf.keras.losses.CategoricalCrossentropy(label_smoothing=0.1)
rnn_model.compile(optimizer=optimizer, loss=loss_fn, metrics=['accuracy', tf.keras.metrics.AUC(name="auc")])
rnn_model.summary()

os.makedirs("./models/affectNetPlus/rnn", exist_ok=True)
checkpoint = ModelCheckpoint("models/affectNetPlus/rnn/improved_rnn_model.h5", monitor='val_accuracy', save_best_only=True, mode='max', verbose=1)
early_stop = EarlyStopping(monitor='val_accuracy', patience=10, restore_best_weights=True, verbose=1)
tensorboard = TensorBoard(log_dir="./logs/affectNetPlus/rnn", histogram_freq=1)
metrics_callback = MetricsCallback(validation_data=validation_generator, batch_size=batch_size)
callbacks = [checkpoint, early_stop, tensorboard, metrics_callback]

history = rnn_model.fit(
    train_generator,
    steps_per_epoch=train_generator.samples // batch_size,
    epochs=epochs,
    validation_data=validation_generator,
    validation_steps=validation_generator.samples // batch_size,
    callbacks=callbacks
)

with open("./models/affectNetPlus/rnn/rnn_training_history.pkl", "wb") as f:
    pickle.dump(history.history, f)

val_loss, val_accuracy, val_auc = rnn_model.evaluate(validation_generator, steps=validation_generator.samples // batch_size)
print(f"Validation Accuracy: {val_accuracy * 100:.2f}%")
print(f"Validation AUC: {val_auc:.4f}")

validation_generator.reset()
y_pred = rnn_model.predict(validation_generator)
y_pred_classes = np.argmax(y_pred, axis=1)
y_true = validation_generator.classes
print("\nClassification Report:")
print(classification_report(y_true, y_pred_classes, target_names=list(class_indices.keys())))

plt.figure(figsize=(10, 8))
cm = confusion_matrix(y_true, y_pred_classes)
sns.heatmap(cm, annot=True, fmt='d', xticklabels=list(class_indices.keys()), yticklabels=list(class_indices.keys()))
plt.title('Confusion Matrix')
plt.xlabel('Predicted Classes')
plt.ylabel('True Classes')
plt.tight_layout()
plt.savefig('rnn_confusion_matrix.png')

rnn_model.save("models/affectNetPlus/rnn/final_rnn_model.h5")