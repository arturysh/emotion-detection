import os
import pickle
import time
import random
import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, models
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping, TensorBoard
from tensorflow.keras.regularizers import l2
from sklearn.metrics import f1_score, roc_auc_score, classification_report, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns

seed_value = 42
tf.random.set_seed(seed_value)
np.random.seed(seed_value)
random.seed(seed_value)

train_dir = "./dataset/fer2013.txt/train"
val_dir = "./dataset/fer2013.txt/test"
img_height, img_width = 48, 48
input_shape = (img_height, img_width, 1)
batch_size = 32
epochs = 50

train_datagen = ImageDataGenerator(
    rescale=1.0/255,
    rotation_range=15,
    zoom_range=0.2,
    shear_range=0.1,
    horizontal_flip=True,
    brightness_range=[0.9, 1.1],
    fill_mode="nearest"
)
val_datagen = ImageDataGenerator(rescale=1.0/255)

train_generator = train_datagen.flow_from_directory(
    train_dir,
    target_size=(img_height, img_width),
    color_mode="grayscale",
    batch_size=batch_size,
    class_mode="categorical",
    shuffle=True,
    seed=seed_value
)
validation_generator = val_datagen.flow_from_directory(
    val_dir,
    target_size=(img_height, img_width),
    color_mode="grayscale",
    batch_size=batch_size,
    class_mode="categorical",
    shuffle=False,
    seed=seed_value
)

num_classes = len(train_generator.class_indices)
print("Classes:", num_classes)

class Patches(layers.Layer):
    def __init__(self, patch_size, **kwargs):
        super(Patches, self).__init__(**kwargs)
        self.patch_size = patch_size
    def call(self, images):
        batch_size = tf.shape(images)[0]
        patches = tf.image.extract_patches(
            images=images,
            sizes=[1, self.patch_size, self.patch_size, 1],
            strides=[1, self.patch_size, self.patch_size, 1],
            rates=[1, 1, 1, 1],
            padding='VALID'
        )
        patch_dims = patches.shape[-1]
        patches = tf.reshape(patches, [batch_size, -1, patch_dims])
        return patches

class PatchEncoder(layers.Layer):
    def __init__(self, num_patches, projection_dim, **kwargs):
        super(PatchEncoder, self).__init__(**kwargs)
        self.num_patches = num_patches
        self.projection = layers.Dense(units=projection_dim)
        self.position_embedding = layers.Embedding(input_dim=num_patches, output_dim=projection_dim)
    def call(self, patches):
        positions = tf.range(start=0, limit=self.num_patches, delta=1)
        encoded = self.projection(patches) + self.position_embedding(positions)
        return encoded

class MetricsCallback(tf.keras.callbacks.Callback):
    def __init__(self, validation_data, batch_size):
        super(MetricsCallback, self).__init__()
        self.validation_data = validation_data
        self.batch_size = batch_size
    def on_epoch_end(self, epoch, logs=None):
        logs = logs or {}
        y_pred = self.model.predict(self.validation_data, verbose=0)
        y_true = self.validation_data.classes
        y_pred_classes = np.argmax(y_pred, axis=1)
        f1 = f1_score(y_true, y_pred_classes, average='weighted')
        try:
            y_true_onehot = tf.keras.utils.to_categorical(y_true, num_classes=y_pred.shape[1])
            roc_auc = roc_auc_score(y_true_onehot, y_pred, multi_class='ovr', average='weighted')
        except Exception as e:
            roc_auc = 0.0
        val_batch = next(iter(self.validation_data))
        start_time = time.time()
        _ = self.model.predict(val_batch[0], verbose=0)
        elapsed_time = time.time() - start_time
        latency = (elapsed_time / self.batch_size) * 1000
        throughput = self.batch_size / elapsed_time
        logs['val_f1'] = f1
        logs['val_roc_auc'] = roc_auc
        print(f"\nEpoch {epoch+1}: val_f1: {f1:.4f}, val_roc_auc: {roc_auc:.4f}")
        print(f"Average latency per image: {latency:.2f} ms, Throughput: {throughput:.2f} images/sec")

def build_vit_model(input_shape, num_classes, patch_size=6, projection_dim=64,
                    transformer_layers=4, num_heads=4, transformer_units=[128, 64],
                    mlp_head_units=[128], dropout_rate=0.1, l2_lambda=1e-4):
    inputs = layers.Input(shape=input_shape)
    patches = Patches(patch_size)(inputs)
    num_patches = (img_height // patch_size) * (img_width // patch_size)
    encoded_patches = PatchEncoder(num_patches, projection_dim)(patches)
    for _ in range(transformer_layers):
        x1 = layers.LayerNormalization(epsilon=1e-6)(encoded_patches)
        attention_output = layers.MultiHeadAttention(num_heads=num_heads,
                                                     key_dim=projection_dim,
                                                     dropout=dropout_rate)(x1, x1)
        x2 = layers.Add()([attention_output, encoded_patches])
        x3 = layers.LayerNormalization(epsilon=1e-6)(x2)
        mlp_output = layers.Dense(transformer_units[0], activation='relu',
                                  kernel_regularizer=l2(l2_lambda))(x3)
        mlp_output = layers.Dropout(dropout_rate)(mlp_output)
        mlp_output = layers.Dense(transformer_units[1], activation='relu',
                                  kernel_regularizer=l2(l2_lambda))(mlp_output)
        mlp_output = layers.Dropout(dropout_rate)(mlp_output)
        encoded_patches = layers.Add()([mlp_output, x2])
    representation = layers.LayerNormalization(epsilon=1e-6)(encoded_patches)
    representation = layers.GlobalAveragePooling1D()(representation)
    for units in mlp_head_units:
        representation = layers.Dense(units, activation='relu', kernel_regularizer=l2(l2_lambda))(representation)
        representation = layers.Dropout(dropout_rate)(representation)
    outputs = layers.Dense(num_classes, activation='softmax')(representation)
    model = models.Model(inputs=inputs, outputs=outputs)
    return model

def train_model_vit(model, train_generator, validation_generator, epochs, batch_size):
    lr_schedule = tf.keras.optimizers.schedules.ExponentialDecay(
        initial_learning_rate=0.001,
        decay_steps=10000,
        decay_rate=0.96,
        staircase=True
    )
    optimizer = Adam(learning_rate=lr_schedule)
    loss_fn = tf.keras.losses.CategoricalCrossentropy(label_smoothing=0.1)
    model.compile(optimizer=optimizer, loss=loss_fn, metrics=['accuracy', tf.keras.metrics.AUC(name="auc")])
    model.summary()
    os.makedirs("./models/fer2013.txt", exist_ok=True)
    checkpoint = ModelCheckpoint("models/fer2013.txt/improved_vit_model.h5", monitor='val_accuracy', verbose=1, save_best_only=True, mode='max')
    early_stop = EarlyStopping(monitor='val_accuracy', patience=10, verbose=1, mode='max')
    tensorboard = TensorBoard(log_dir="./logs/fer2013.txt/vit", histogram_freq=1)
    metrics_callback = MetricsCallback(validation_data=validation_generator, batch_size=batch_size)
    callbacks_list = [checkpoint, early_stop, tensorboard, metrics_callback]
    history = model.fit(
        train_generator,
        steps_per_epoch=train_generator.samples // batch_size,
        epochs=epochs,
        validation_data=validation_generator,
        validation_steps=validation_generator.samples // batch_size,
        callbacks=callbacks_list
    )
    with open("./models/fer2013.txt/vit_training_history.pkl", "wb") as f:
        pickle.dump(history.history, f)
    loss, accuracy, auc = model.evaluate(validation_generator, steps=validation_generator.samples // batch_size)
    print("Improved ViT - Validation Accuracy: {:.2f}%".format(accuracy * 100))
    print("Improved ViT - Validation AUC: {:.4f}".format(auc))
    return history

patch_size = 6
projection_dim = 64
transformer_layers = 4
num_heads = 4
transformer_units = [128, 64]
mlp_head_units = [128]
dropout_rate = 0.1

vit_model = build_vit_model(
    input_shape=input_shape,
    num_classes=num_classes,
    patch_size=patch_size,
    projection_dim=projection_dim,
    transformer_layers=transformer_layers,
    num_heads=num_heads,
    transformer_units=transformer_units,
    mlp_head_units=mlp_head_units,
    dropout_rate=dropout_rate,
    l2_lambda=1e-4
)

history = train_model_vit(vit_model, train_generator, validation_generator, epochs, batch_size)

validation_generator.reset()
y_pred = vit_model.predict(validation_generator)
y_pred_classes = np.argmax(y_pred, axis=1)
y_true = validation_generator.classes
print("\nClassification Report:")
print(classification_report(y_true, y_pred_classes, target_names=list(train_generator.class_indices.keys())))

plt.figure(figsize=(10, 8))
cm = confusion_matrix(y_true, y_pred_classes)
sns.heatmap(cm, annot=True, fmt='d', xticklabels=list(train_generator.class_indices.keys()),
            yticklabels=list(train_generator.class_indices.keys()))
plt.title('Confusion Matrix')
plt.xlabel('Predicted Classes')
plt.ylabel('True Classes')
plt.tight_layout()
plt.savefig('vit_confusion_matrix.png')

vit_model.save("models/fer2013.txt/improved_vit_model_final.h5")