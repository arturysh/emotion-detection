import tensorflow as tf
from config import Config

class ModelManager:
    def __init__(self):
        self.cnn_model = None
        self.rnn_model = None
        self.vit_model = None
        self.load_models()

    def load_models(self):
        self.cnn_model = tf.keras.models.load_model(Config.CNN_MODEL_PATH)
        self.rnn_model = tf.keras.models.load_model(Config.RNN_MODEL_PATH)
        self.vit_model = tf.keras.models.load_model(Config.VIT_MODEL_PATH)

    def get_models(self):
        return {
            "cnn": self.cnn_model,
            "rnn": self.rnn_model,
            "vit": self.vit_model
        }